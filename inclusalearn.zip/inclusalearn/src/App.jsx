import { useState, useEffect, useRef, useCallback } from "react";
import {
  LayoutDashboard, Users, BookOpen, TrendingUp, Brain, MessageSquare,
  Package, Shield, FileText, Sparkles, ChevronRight, Bell, Search,
  Plus, X, Check, AlertTriangle, Info, Volume2, Eye, Ear, BookMarked,
  Accessibility, Activity, Calendar, Clock, Download, Send, Filter,
  BarChart2, Target, Heart, Star, ArrowUp, ArrowDown, Minus, Mic,
  MicOff, Settings, LogOut, Menu, ChevronDown, Zap, Award, Globe,
  Phone, Mail, Edit, Trash2, Save, RefreshCw, FileDown, CheckCircle,
  XCircle, AlertCircle, User, UserPlus, ClipboardList, Printer,
  ToggleLeft, ToggleRight, SunMedium, Moon, Type
} from "lucide-react";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area,
  RadarChart, Radar, PolarGrid, PolarAngleAxis, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer
} from "recharts";

// ═══════════════════════════════════════════
// INITIAL DATA
// ═══════════════════════════════════════════
const INITIAL_STUDENTS = [
  {
    id: "STU-001", name: "Rohan Sharma", age: 13, grade: "Grade 7",
    disability: "Visual Impairment", severity: "Moderate",
    contentMode: "Audio-First", avatar: "RS",
    color: "#4f9cf9", bg: "linear-gradient(135deg,#1a3a5c,#0f2a45)",
    academicProgress: 38, therapyEngagement: 25, attendance: 42,
    socialScore: 40, emotionalScore: 55, selfScore: 30,
    riskLevel: "Critical", trend: "declining",
    therapist: "Dr. Kavita Iyer", therapistType: "Speech Therapist",
    goals: "Improve audio comprehension, develop screen-reader fluency, oral communication",
    parentContact: "Suresh Sharma | +91 98765 43210",
    joinDate: "2025-06-15",
    milestones: [
      { name: "Audio Module 1", done: true }, { name: "Audio Module 2", done: true },
      { name: "Audio Module 3", done: true }, { name: "Oral Assessment 1", done: false },
      { name: "Audio Module 4", done: false }, { name: "Braille Basics", done: false }
    ],
    monthlyProgress: [
      { month: "Aug", academic: 20, therapy: 15 }, { month: "Sep", academic: 25, therapy: 18 },
      { month: "Oct", academic: 30, therapy: 20 }, { month: "Nov", academic: 35, therapy: 22 },
      { month: "Dec", academic: 33, therapy: 20 }, { month: "Jan", academic: 38, therapy: 25 }
    ],
    therapyLogs: [
      { date: "2026-02-20", type: "Speech Therapy", duration: 45, therapist: "Dr. Kavita Iyer", notes: "Practiced articulation of f/v sounds. Improved response time.", resources: ["Audio Device"], outcome: "Good" },
      { date: "2026-02-13", type: "Speech Therapy", duration: 45, therapist: "Dr. Kavita Iyer", notes: "Word card session. 12 cards completed with audio feedback.", resources: ["Audio Device"], outcome: "Moderate" }
    ],
    accommodations: ["Screen reader software", "Audio textbooks", "Extended test time", "Oral exams"]
  },
  {
    id: "STU-002", name: "Priya Arora", age: 12, grade: "Grade 6",
    disability: "Autism Spectrum", severity: "Moderate",
    contentMode: "Structured Modules", avatar: "PA",
    color: "#3ecf8e", bg: "linear-gradient(135deg,#1a3025,#0f2019)",
    academicProgress: 72, therapyEngagement: 88, attendance: 91,
    socialScore: 60, emotionalScore: 70, selfScore: 75,
    riskLevel: "Low", trend: "improving",
    therapist: "Ms. Reena Sharma", therapistType: "Occupational Therapist",
    goals: "Routine adherence, social communication, sensory regulation, independent task completion",
    parentContact: "Meena Arora | +91 87654 32109",
    joinDate: "2025-04-10",
    milestones: [
      { name: "Routine Module 1", done: true }, { name: "Routine Module 2", done: true },
      { name: "Social Skills 1", done: true }, { name: "Sensory Integration", done: true },
      { name: "Social Skills 2", done: true }, { name: "Independent Tasks", done: true },
      { name: "Routine Module 3", done: true }, { name: "Peer Interaction", done: false },
      { name: "Advanced Social", done: false }, { name: "Final Review", done: false }
    ],
    monthlyProgress: [
      { month: "Aug", academic: 45, therapy: 55 }, { month: "Sep", academic: 52, therapy: 64 },
      { month: "Oct", academic: 60, therapy: 72 }, { month: "Nov", academic: 65, therapy: 80 },
      { month: "Dec", academic: 70, therapy: 85 }, { month: "Jan", academic: 72, therapy: 88 }
    ],
    therapyLogs: [
      { date: "2026-02-20", type: "Occupational Therapy", duration: 60, therapist: "Ms. Reena Sharma", notes: "Fine motor skills. Bead threading Level 3 complete. 52 min focus.", resources: ["Sensory Tools"], outcome: "Excellent" },
      { date: "2026-02-13", type: "Occupational Therapy", duration: 60, therapist: "Ms. Reena Sharma", notes: "Clay work and weighted blanket protocol. Excellent sensory regulation.", resources: ["Sensory Tools", "Weighted Blanket"], outcome: "Good" }
    ],
    accommodations: ["Visual schedules", "Sensory breaks", "Quiet workspace", "Routine-based curriculum"]
  },
  {
    id: "STU-003", name: "Ayaan Khan", age: 14, grade: "Grade 8",
    disability: "Hearing Impairment", severity: "Severe",
    contentMode: "Sign + Subtitles", avatar: "AK",
    color: "#7c6ff7", bg: "linear-gradient(135deg,#2a1a3a,#1a0f25)",
    academicProgress: 65, therapyEngagement: 60, attendance: 78,
    socialScore: 62, emotionalScore: 68, selfScore: 70,
    riskLevel: "Low", trend: "stable",
    therapist: "Ms. Deepa Nair", therapistType: "Sign Language Specialist",
    goals: "ISL fluency, academic comprehension via sign, peer communication, written expression",
    parentContact: "Farzana Khan | +91 76543 21098",
    joinDate: "2025-05-20",
    milestones: [
      { name: "ISL Basics", done: true }, { name: "ISL Level 2", done: true },
      { name: "Caption Comprehension", done: true }, { name: "Peer Sign Intro", done: true },
      { name: "ISL Level 3", done: true }, { name: "Science ISL", done: false },
      { name: "Math ISL", done: false }, { name: "ISL Fluency Test", done: false },
      { name: "Social Communication", done: false }
    ],
    monthlyProgress: [
      { month: "Aug", academic: 40, therapy: 35 }, { month: "Sep", academic: 48, therapy: 42 },
      { month: "Oct", academic: 54, therapy: 50 }, { month: "Nov", academic: 60, therapy: 55 },
      { month: "Dec", academic: 63, therapy: 58 }, { month: "Jan", academic: 65, therapy: 60 }
    ],
    therapyLogs: [
      { date: "2026-02-19", type: "Sign Language Session", duration: 45, therapist: "Ms. Deepa Nair", notes: "Mastered 18 new ISL signs. Conversational practice with peers.", resources: ["Sign Interpreter"], outcome: "Good" }
    ],
    accommodations: ["ISL interpreter", "Real-time captioning", "Visual alerts", "FM system"]
  },
  {
    id: "STU-004", name: "Meera Rao", age: 11, grade: "Grade 5",
    disability: "Dyslexia", severity: "Mild",
    contentMode: "Simplified Visual", avatar: "MR",
    color: "#f87171", bg: "linear-gradient(135deg,#3a1a1a,#251010)",
    academicProgress: 81, therapyEngagement: 95, attendance: 96,
    socialScore: 85, emotionalScore: 88, selfScore: 80,
    riskLevel: "Minimal", trend: "excellent",
    therapist: "Dr. Priya Menon", therapistType: "Educational Psychologist",
    goals: "Phonics mastery, reading independence, reduce TTS dependency, written expression",
    parentContact: "Sunita Rao | +91 65432 10987",
    joinDate: "2025-03-01",
    milestones: [
      { name: "Phonics L1", done: true }, { name: "Phonics L2", done: true },
      { name: "Phonics L3", done: true }, { name: "Visual Reading 1", done: true },
      { name: "Visual Reading 2", done: true }, { name: "Word Games 1", done: true },
      { name: "Word Games 2", done: true }, { name: "Short Stories", done: true },
      { name: "Phonics L4", done: true }, { name: "Chapter Book 1", done: false },
      { name: "Independent Reading", done: false }
    ],
    monthlyProgress: [
      { month: "Aug", academic: 55, therapy: 70 }, { month: "Sep", academic: 62, therapy: 78 },
      { month: "Oct", academic: 68, therapy: 84 }, { month: "Nov", academic: 74, therapy: 89 },
      { month: "Dec", academic: 78, therapy: 92 }, { month: "Jan", academic: 81, therapy: 95 }
    ],
    therapyLogs: [
      { date: "2026-02-18", type: "Educational Psychology", duration: 30, therapist: "Dr. Priya Menon", notes: "Phonics Level 4 assessment passed with 88%. Ready for chapter books.", resources: [], outcome: "Excellent" }
    ],
    accommodations: ["Dyslexia-friendly font", "Text-to-speech", "Extended time", "Audio books"]
  },
  {
    id: "STU-005", name: "Siddharth Kumar", age: 15, grade: "Grade 9",
    disability: "Physical Disability", severity: "Moderate",
    contentMode: "Standard + Adaptive", avatar: "SK",
    color: "#2dd4bf", bg: "linear-gradient(135deg,#1a2a3a,#0f1a25)",
    academicProgress: 91, therapyEngagement: 78, attendance: 89,
    socialScore: 88, emotionalScore: 85, selfScore: 92,
    riskLevel: "Minimal", trend: "excellent",
    therapist: "Ms. Rekha Das", therapistType: "Physical Therapist",
    goals: "Motor independence, academic excellence, assistive tech mastery",
    parentContact: "Ramesh Kumar | +91 54321 09876",
    joinDate: "2025-02-15",
    milestones: [
      { name: "Adaptive Tech Setup", done: true }, { name: "Switch Access Training", done: true },
      { name: "Eye Tracking Basics", done: true }, { name: "Academic Module 1", done: true },
      { name: "Academic Module 2", done: true }, { name: "Independence Skills", done: true },
      { name: "Advanced AAC", done: false }
    ],
    monthlyProgress: [
      { month: "Aug", academic: 72, therapy: 60 }, { month: "Sep", academic: 78, therapy: 65 },
      { month: "Oct", academic: 83, therapy: 70 }, { month: "Nov", academic: 87, therapy: 74 },
      { month: "Dec", academic: 89, therapy: 77 }, { month: "Jan", academic: 91, therapy: 78 }
    ],
    therapyLogs: [
      { date: "2026-02-17", type: "Physical Therapy", duration: 45, therapist: "Ms. Rekha Das", notes: "Improved fine motor control. Eye tracking response time down to 1.2s.", resources: ["AAC Device", "Eye Tracker"], outcome: "Excellent" }
    ],
    accommodations: ["Switch access", "Eye-tracking software", "AAC device", "Accessible desk"]
  },
  {
    id: "STU-006", name: "Nisha Patel", age: 10, grade: "Grade 4",
    disability: "Autism Spectrum", severity: "Moderate",
    contentMode: "Structured Modules", avatar: "NP",
    color: "#fb923c", bg: "linear-gradient(135deg,#2a2a1a,#1a1a0f)",
    academicProgress: 55, therapyEngagement: 70, attendance: 74,
    socialScore: 35, emotionalScore: 45, selfScore: 50,
    riskLevel: "Moderate", trend: "stable",
    therapist: "Dr. Anjali Roy", therapistType: "Psychologist",
    goals: "Emotional regulation, social interaction, meltdown reduction, routine building",
    parentContact: "Divya Patel | +91 43210 98765",
    joinDate: "2025-07-01",
    milestones: [
      { name: "Emotion Cards Level 1", done: true }, { name: "Routine Chart", done: true },
      { name: "Sensory Profile", done: true }, { name: "Emotion Cards Level 2", done: true },
      { name: "Social Stories 1", done: false }, { name: "Peer Interaction 1", done: false }
    ],
    monthlyProgress: [
      { month: "Aug", academic: 35, therapy: 45 }, { month: "Sep", academic: 40, therapy: 52 },
      { month: "Oct", academic: 46, therapy: 58 }, { month: "Nov", academic: 50, therapy: 63 },
      { month: "Dec", academic: 52, therapy: 67 }, { month: "Jan", academic: 55, therapy: 70 }
    ],
    therapyLogs: [
      { date: "2026-02-17", type: "Psychological Support", duration: 30, therapist: "Dr. Anjali Roy", notes: "Emotion identification session. Identified 4 distinct emotions — up from 1 three weeks ago.", resources: ["Emotion Cards"], outcome: "Good" }
    ],
    accommodations: ["Sensory-safe space", "Noise-canceling headphones", "Visual schedules", "Emotion regulation toolkit"]
  }
];

const THERAPISTS = [
  { id: "T1", name: "Dr. Kavita Iyer", role: "Speech Therapist", students: 12, status: "Available", avatar: "KI", color: "#4f9cf9" },
  { id: "T2", name: "Ms. Reena Sharma", role: "Occupational Therapist", students: 9, status: "In Session", avatar: "RS", color: "#3ecf8e" },
  { id: "T3", name: "Dr. Anjali Roy", role: "Psychologist", students: 7, status: "Available", avatar: "AR", color: "#f87171" },
  { id: "T4", name: "Ms. Deepa Nair", role: "Sign Language Specialist", students: 8, status: "Available", avatar: "DN", color: "#7c6ff7" },
  { id: "T5", name: "Ms. Rekha Das", role: "Physical Therapist", students: 6, status: "On Leave", avatar: "RD", color: "#fb923c" },
  { id: "T6", name: "Dr. Priya Menon", role: "Educational Psychologist", students: 10, status: "Available", avatar: "PM", color: "#2dd4bf" }
];

const RESOURCES = [
  { id: "R1", name: "Audio Equipment", icon: "🔊", desc: "Screen readers, FM systems, hearing loops", total: 38, inUse: 24, color: "#4f9cf9" },
  { id: "R2", name: "Braille Materials", icon: "📟", desc: "Braille displays, embossers, tactile books", total: 30, inUse: 22, color: "#7c6ff7" },
  { id: "R3", name: "Sign Support", icon: "🤟", desc: "ISL interpreters, captioning, visual alerts", total: 15, inUse: 8, color: "#3ecf8e" },
  { id: "R4", name: "Sensory Kits", icon: "🧸", desc: "Weighted blankets, fidget tools, noise-canceling", total: 24, inUse: 15, color: "#f59e0b" },
  { id: "R5", name: "Adaptive Tech", icon: "💻", desc: "Switch access, eye-tracking, AAC devices", total: 24, inUse: 18, color: "#2dd4bf" },
  { id: "R6", name: "Mobility Aids", icon: "♿", desc: "Wheelchairs, ramps, accessible furniture", total: 12, inUse: 7, color: "#fb923c" }
];

const INITIAL_MESSAGES = [
  { id: 1, from: "Dr. Kavita Iyer", fromRole: "Speech Therapist", avatar: "KI", color: "#4f9cf9", student: "Rohan Sharma", subject: "ILP Audio Update", body: "Rohan's audio comprehension is improving but written output lags behind. Can we sync the ILP to emphasize dictation tools and reduce written assessments this semester?", time: "2h ago", priority: "Normal", replies: 3, unread: true },
  { id: 2, from: "Anaya Mehta", fromRole: "Special Educator", avatar: "AM", color: "#3ecf8e", student: "Priya Arora", subject: "Routine Schedule Update", body: "Priya's updated routine schedule now includes a 10:30 AM sensory break. All teachers please review before Monday. The new visual schedule has been printed and laminated.", time: "5h ago", priority: "Normal", replies: 1, unread: false },
  { id: 3, from: "Dr. Anjali Roy", fromRole: "Psychologist", avatar: "AR", color: "#f87171", student: "Nisha Patel", subject: "⚠ URGENT: Sensory Incident", body: "Nisha had a meltdown during recess triggered by loud noise and crowding. Requesting designation of a sensory-safe space near classroom 4B. Full incident report filed in the system.", time: "Yesterday", priority: "Urgent", replies: 5, unread: true },
  { id: 4, from: "Ms. Deepa Nair", fromRole: "Sign Language Specialist", avatar: "DN", color: "#7c6ff7", student: "Ayaan Khan", subject: "Science Class ISL Request", body: "Ayaan needs an ISL interpreter for the upcoming science lab sessions starting next week. The technical vocabulary requires specialized sign support. Please approve resource allocation.", time: "2 days ago", priority: "For Review", replies: 0, unread: true }
];

const COMPLIANCE_ITEMS = [
  { id: 1, title: "Disability Documentation (PWDRA 2016)", desc: "All 127 students have valid disability certificates", status: "ok", pct: 100 },
  { id: 2, title: "Individualized Education Plans", desc: "127/127 IEPs active and signed by guardians", status: "ok", pct: 100 },
  { id: 3, title: "Accessibility Accommodations", desc: "Documented for 119 students — 8 pending", status: "ok", pct: 94 },
  { id: 4, title: "Therapy Session Logs", desc: "7 sessions missing therapist signatures", status: "warn", pct: 88 },
  { id: 5, title: "Parent/Guardian Consent Forms", desc: "3 forms due for renewal this month", status: "warn", pct: 97 },
  { id: 6, title: "Annual Review Schedule", desc: "All 14 Q1 reviews scheduled and notified", status: "ok", pct: 100 },
  { id: 7, title: "Staff Disability Awareness Training", desc: "23/23 staff completed certification", status: "ok", pct: 100 },
  { id: 8, title: "Infrastructure Accessibility Audit", desc: "Annual audit report not yet submitted for 2026", status: "fail", pct: 0 }
];

const AI_RECOMMENDATIONS = {
  "STU-001": [
    { title: "Switch to 100% Audio Curriculum", detail: "Current text-heavy modules show 40% lower retention. Audio-first with NVDA-compatible format recommended.", confidence: 87, tag: "High Impact" },
    { title: "Add Dictation-Based Assessments", detail: "Remove written exams, replace with voice-recorded answers. Predicted performance improvement: +35%.", confidence: 91, tag: "Assessment" },
    { title: "Increase Session Frequency", detail: "Current 2x/week shows plateau. 3x/week speech therapy predicts 60% faster articulation gains.", confidence: 78, tag: "Therapy" }
  ],
  "STU-002": [
    { title: "Introduce Visual Task Cards", detail: "15-minute structured blocks with visual timer shown to increase task completion by 62% in similar profiles.", confidence: 92, tag: "High Impact" },
    { title: "Add 10:30 AM Sensory Break", detail: "Engagement dips at 10:15 AM daily. Scheduled sensory break resolves this with 91% confidence.", confidence: 91, tag: "Routine" },
    { title: "Advance to Social Stories Level 2", detail: "Priya has mastered Level 1 social scripts. Peer interaction module is next logical step.", confidence: 84, tag: "Social" }
  ],
  "STU-003": [
    { title: "ISL-Annotated Video Library", detail: "Current captioning-only approach shows 35% comprehension gap. Sign-annotated videos close this significantly.", confidence: 88, tag: "High Impact" },
    { title: "Real-Time Captioning in Science", detail: "Technical terminology causes confusion. Dedicated ISL interpreter for lab sessions recommended.", confidence: 82, tag: "Academic" },
    { title: "Peer Sign Language Buddy Program", detail: "Social integration improved 70% when hearing peers learn basic ISL. Recommend inclusion activity.", confidence: 76, tag: "Social" }
  ],
  "STU-004": [
    { title: "Advance to Level 4 Phonics", detail: "Meera has plateaued at Level 3. Progress speed suggests readiness for advanced phonics games.", confidence: 94, tag: "Ready Now" },
    { title: "Introduce Chapter Books", detail: "OpenDyslexic formatted readers with high contrast appropriate for current skill level.", confidence: 87, tag: "Reading" },
    { title: "Reduce TTS Dependency Gradually", detail: "Strong improvement detected. TTS reduction (80%→60%→40%) recommended to build independence.", confidence: 79, tag: "Independence" }
  ],
  "STU-005": [
    { title: "Advanced AAC Communication Board", detail: "Current vocabulary board is at 80% capacity. Expanding to 200+ symbols recommended.", confidence: 90, tag: "High Impact" },
    { title: "Peer Collaboration Projects", detail: "Academic excellence suggests readiness for group work with accessibility accommodations.", confidence: 85, tag: "Social" }
  ],
  "STU-006": [
    { title: "Sensory Diet Protocol", detail: "Meltdown frequency can be reduced 65% with structured sensory diet throughout the day.", confidence: 88, tag: "Urgent" },
    { title: "Emotion Regulation Toolkit", detail: "CBT-adapted emotion cards showing excellent results. Advance to Level 3 emotion complexity.", confidence: 82, tag: "Emotional" },
    { title: "Safe Space Designation", detail: "Sensory-safe space near classroom critical. Location 4B recommended based on noise mapping.", confidence: 95, tag: "Environment" }
  ]
};

// ═══════════════════════════════════════════
// UTILITY COMPONENTS
// ═══════════════════════════════════════════
const Avatar = ({ initials, color, size = 36 }) => (
  <div style={{
    width: size, height: size, borderRadius: "50%",
    background: color || "linear-gradient(135deg,#4f9cf9,#7c6ff7)",
    display: "flex", alignItems: "center", justifyContent: "center",
    color: "#fff", fontWeight: 700, fontSize: size * 0.35, flexShrink: 0,
    fontFamily: "'DM Sans', sans-serif"
  }}>{initials}</div>
);

const Tag = ({ children, color = "blue" }) => {
  const colors = {
    blue: { bg: "rgba(79,156,249,0.15)", text: "#4f9cf9" },
    green: { bg: "rgba(62,207,142,0.15)", text: "#3ecf8e" },
    amber: { bg: "rgba(245,158,11,0.15)", text: "#f59e0b" },
    red: { bg: "rgba(248,113,113,0.15)", text: "#f87171" },
    purple: { bg: "rgba(124,111,247,0.15)", text: "#7c6ff7" },
    pink: { bg: "rgba(244,114,182,0.15)", text: "#f472b6" },
    teal: { bg: "rgba(45,212,191,0.15)", text: "#2dd4bf" },
    orange: { bg: "rgba(251,146,60,0.15)", text: "#fb923c" },
    gray: { bg: "rgba(143,163,191,0.15)", text: "#8fa3bf" },
  };
  const c = colors[color] || colors.blue;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      padding: "2px 10px", borderRadius: 20,
      background: c.bg, color: c.text,
      fontSize: 11, fontWeight: 600, letterSpacing: "0.03em", whiteSpace: "nowrap"
    }}>{children}</span>
  );
};

const ProgressBar = ({ value, color = "#4f9cf9", height = 6 }) => (
  <div style={{ width: "100%", height, background: "rgba(255,255,255,0.08)", borderRadius: 99, overflow: "hidden" }}>
    <div style={{
      width: `${Math.min(100, Math.max(0, value))}%`, height: "100%",
      background: color, borderRadius: 99, transition: "width 0.8s ease"
    }} />
  </div>
);

const Card = ({ children, style = {}, onClick }) => (
  <div onClick={onClick} style={{
    background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 14, padding: 20,
    transition: "border-color 0.2s, transform 0.2s, box-shadow 0.2s",
    cursor: onClick ? "pointer" : "default",
    ...style
  }}
    onMouseEnter={e => { if (onClick) { e.currentTarget.style.borderColor = "rgba(255,255,255,0.15)"; e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 8px 30px rgba(0,0,0,0.3)"; } else e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)"; }}
    onMouseLeave={e => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)"; e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = ""; }}
  >{children}</div>
);

const Btn = ({ children, variant = "primary", onClick, style = {}, disabled = false, size = "md" }) => {
  const bases = {
    primary: { background: "linear-gradient(135deg,#4f9cf9,#7c6ff7)", color: "#fff", border: "none", boxShadow: "0 4px 14px rgba(79,156,249,0.3)" },
    ghost: { background: "rgba(255,255,255,0.06)", color: "#8fa3bf", border: "1px solid rgba(255,255,255,0.1)" },
    danger: { background: "rgba(248,113,113,0.15)", color: "#f87171", border: "1px solid rgba(248,113,113,0.25)" },
    success: { background: "rgba(62,207,142,0.15)", color: "#3ecf8e", border: "1px solid rgba(62,207,142,0.25)" },
    warning: { background: "rgba(245,158,11,0.15)", color: "#f59e0b", border: "1px solid rgba(245,158,11,0.25)" },
  };
  const pads = { sm: "5px 12px", md: "9px 18px", lg: "12px 24px" };
  const fontSizes = { sm: 12, md: 13, lg: 14 };
  return (
    <button onClick={onClick} disabled={disabled} style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      padding: pads[size], borderRadius: 8,
      fontSize: fontSizes[size], fontWeight: 600, fontFamily: "'DM Sans', sans-serif",
      cursor: disabled ? "not-allowed", opacity: disabled ? 0.5 : 1,
      transition: "all 0.2s", ...bases[variant], ...style
    }}
      onMouseEnter={e => { if (!disabled) { e.currentTarget.style.transform = "translateY(-1px)"; e.currentTarget.style.filter = "brightness(1.1)"; } }}
      onMouseLeave={e => { e.currentTarget.style.transform = ""; e.currentTarget.style.filter = ""; }}
    >{children}</button>
  );
};

const Modal = ({ open, onClose, title, children, width = 560 }) => {
  if (!open) return null;
  return (
    <div onClick={e => e.target === e.currentTarget && onClose()} style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)",
      backdropFilter: "blur(6px)", zIndex: 1000,
      display: "flex", alignItems: "center", justifyContent: "center", padding: 20
    }}>
      <div style={{
        background: "#111827", border: "1px solid rgba(255,255,255,0.12)",
        borderRadius: 16, padding: 28, width: "100%", maxWidth: width,
        maxHeight: "90vh", overflowY: "auto",
        animation: "slideUp 0.25s ease"
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 22, fontWeight: 700, color: "#e8edf5" }}>{title}</div>
          <button onClick={onClose} style={{
            width: 32, height: 32, borderRadius: "50%", border: "1px solid rgba(255,255,255,0.1)",
            background: "rgba(255,255,255,0.05)", color: "#8fa3bf", cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16
          }}>×</button>
        </div>
        {children}
      </div>
    </div>
  );
};

const FormInput = ({ label, type = "text", value, onChange, placeholder, required }) => (
  <div style={{ marginBottom: 16 }}>
    <label style={{ display: "block", fontSize: 11, fontWeight: 700, color: "#8fa3bf", marginBottom: 6, letterSpacing: "0.06em", textTransform: "uppercase" }}>{label}{required && " *"}</label>
    <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
      style={{
        width: "100%", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
        borderRadius: 8, padding: "10px 14px", color: "#e8edf5",
        fontFamily: "'DM Sans', sans-serif", fontSize: 13, outline: "none",
        boxSizing: "border-box"
      }}
      onFocus={e => e.target.style.borderColor = "#4f9cf9"}
      onBlur={e => e.target.style.borderColor = "rgba(255,255,255,0.12)"}
    />
  </div>
);

const FormSelect = ({ label, value, onChange, options, required }) => (
  <div style={{ marginBottom: 16 }}>
    <label style={{ display: "block", fontSize: 11, fontWeight: 700, color: "#8fa3bf", marginBottom: 6, letterSpacing: "0.06em", textTransform: "uppercase" }}>{label}{required && " *"}</label>
    <select value={value} onChange={e => onChange(e.target.value)}
      style={{
        width: "100%", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
        borderRadius: 8, padding: "10px 14px", color: "#e8edf5",
        fontFamily: "'DM Sans', sans-serif", fontSize: 13, outline: "none"
      }}
      onFocus={e => e.target.style.borderColor = "#4f9cf9"}
      onBlur={e => e.target.style.borderColor = "rgba(255,255,255,0.12)"}
    >
      {options.map(o => <option key={o.value || o} value={o.value || o} style={{ background: "#111827" }}>{o.label || o}</option>)}
    </select>
  </div>
);

const FormTextarea = ({ label, value, onChange, placeholder, rows = 4 }) => (
  <div style={{ marginBottom: 16 }}>
    <label style={{ display: "block", fontSize: 11, fontWeight: 700, color: "#8fa3bf", marginBottom: 6, letterSpacing: "0.06em", textTransform: "uppercase" }}>{label}</label>
    <textarea value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} rows={rows}
      style={{
        width: "100%", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
        borderRadius: 8, padding: "10px 14px", color: "#e8edf5",
        fontFamily: "'DM Sans', sans-serif", fontSize: 13, outline: "none",
        resize: "vertical", boxSizing: "border-box"
      }}
      onFocus={e => e.target.style.borderColor = "#4f9cf9"}
      onBlur={e => e.target.style.borderColor = "rgba(255,255,255,0.12)"}
    />
  </div>
);

const Toast = ({ message, type = "success", onClose }) => {
  useEffect(() => { const t = setTimeout(onClose, 3500); return () => clearTimeout(t); }, []);
  const colors = { success: "#3ecf8e", error: "#f87171", info: "#4f9cf9", warning: "#f59e0b" };
  const icons = { success: <CheckCircle size={16} />, error: <XCircle size={16} />, info: <Info size={16} />, warning: <AlertCircle size={16} /> };
  return (
    <div style={{
      position: "fixed", bottom: 24, right: 24, zIndex: 2000,
      display: "flex", alignItems: "center", gap: 10,
      background: "#1a2235", border: `1px solid ${colors[type]}40`,
      borderLeft: `3px solid ${colors[type]}`, borderRadius: 10,
      padding: "12px 18px", color: "#e8edf5", fontSize: 14, fontWeight: 500,
      boxShadow: "0 8px 30px rgba(0,0,0,0.4)",
      animation: "slideUp 0.3s ease", maxWidth: 360
    }}>
      <span style={{ color: colors[type] }}>{icons[type]}</span>
      <span style={{ flex: 1 }}>{message}</span>
      <button onClick={onClose} style={{ background: "none", border: "none", color: "#8fa3bf", cursor: "pointer", padding: 2 }}>
        <X size={14} />
      </button>
    </div>
  );
};

// ═══════════════════════════════════════════
// RISK BADGE
// ═══════════════════════════════════════════
const RiskBadge = ({ level }) => {
  const map = {
    "Critical": "red", "Moderate": "amber", "Low": "blue", "Minimal": "green"
  };
  return <Tag color={map[level] || "gray"}>{level}</Tag>;
};

const TrendIcon = ({ trend }) => {
  if (trend === "improving" || trend === "excellent") return <span style={{ color: "#3ecf8e", display: "flex", alignItems: "center", gap: 2, fontSize: 12 }}><ArrowUp size={12} /> {trend === "excellent" ? "Excellent" : "Improving"}</span>;
  if (trend === "declining") return <span style={{ color: "#f87171", display: "flex", alignItems: "center", gap: 2, fontSize: 12 }}><ArrowDown size={12} /> Declining</span>;
  return <span style={{ color: "#8fa3bf", display: "flex", alignItems: "center", gap: 2, fontSize: 12 }}><Minus size={12} /> Stable</span>;
};

// ═══════════════════════════════════════════
// SIDEBAR
// ═══════════════════════════════════════════
const NAV_ITEMS = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, section: "Core" },
  { id: "students", label: "Students", icon: Users, section: "Core", badge: null },
  { id: "learning-plans", label: "Learning Plans", icon: BookOpen, section: "Core" },
  { id: "progress", label: "Progress Tracking", icon: TrendingUp, section: "Core" },
  { id: "therapy", label: "Therapy Logs", icon: Brain, section: "Support" },
  { id: "collaboration", label: "Collaboration", icon: MessageSquare, section: "Support", badge: "3" },
  { id: "resources", label: "Resources", icon: Package, section: "Support" },
  { id: "compliance", label: "Compliance", icon: Shield, section: "Admin" },
  { id: "reports", label: "Reports", icon: FileText, section: "Admin" },
  { id: "ai", label: "AI Insights", icon: Sparkles, section: "Admin" },
];

const Sidebar = ({ active, onNav, students, messages }) => {
  const unread = messages.filter(m => m.unread).length;
  return (
    <div style={{
      width: 260, background: "rgba(17,24,39,0.95)", borderRight: "1px solid rgba(255,255,255,0.06)",
      display: "flex", flexDirection: "column", position: "fixed",
      left: 0, top: 0, bottom: 0, zIndex: 100, overflowY: "auto"
    }}>
      {/* Logo */}
      <div style={{ padding: "22px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{
            width: 40, height: 40, borderRadius: 11,
            background: "linear-gradient(135deg,#4f9cf9,#7c6ff7)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 20, boxShadow: "0 0 20px rgba(79,156,249,0.35)", flexShrink: 0
          }}>♾</div>
          <div>
            <div style={{ fontFamily: "'Fraunces', serif", fontSize: 18, fontWeight: 700, color: "#e8edf5", lineHeight: 1 }}>InclusaLearn</div>
            <div style={{ fontSize: 10, color: "#5a7090", fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", marginTop: 2 }}>Edu Ecosystem</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ padding: "14px 12px", flex: 1 }}>
        {["Core", "Support", "Admin"].map(section => (
          <div key={section}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "#3a4a5c", padding: "10px 8px 4px", marginTop: 6 }}>{section}</div>
            {NAV_ITEMS.filter(n => n.section === section).map(item => {
              const Icon = item.icon;
              const isActive = active === item.id;
              const badgeCount = item.id === "students" ? students.length : item.id === "collaboration" ? unread : null;
              return (
                <div key={item.id} onClick={() => onNav(item.id)}
                  style={{
                    display: "flex", alignItems: "center", gap: 10,
                    padding: "10px 12px", borderRadius: 8, cursor: "pointer",
                    fontSize: 14, fontWeight: 500, marginBottom: 2,
                    background: isActive ? "linear-gradient(135deg,rgba(79,156,249,0.15),rgba(124,111,247,0.1))" : "transparent",
                    color: isActive ? "#4f9cf9" : "#8fa3bf",
                    border: `1px solid ${isActive ? "rgba(79,156,249,0.2)" : "transparent"}`,
                    transition: "all 0.2s"
                  }}
                  onMouseEnter={e => { if (!isActive) { e.currentTarget.style.background = "rgba(255,255,255,0.04)"; e.currentTarget.style.color = "#e8edf5"; } }}
                  onMouseLeave={e => { if (!isActive) { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "#8fa3bf"; } }}
                >
                  <Icon size={16} style={{ flexShrink: 0 }} />
                  <span style={{ flex: 1 }}>{item.label}</span>
                  {badgeCount > 0 && (
                    <span style={{
                      background: item.id === "collaboration" ? "#f87171" : "#3ecf8e",
                      color: "#fff", fontSize: 10, fontWeight: 700,
                      padding: "2px 6px", borderRadius: 20, lineHeight: 1.4
                    }}>{badgeCount}</span>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </nav>

      {/* User */}
      <div style={{ padding: "14px 12px", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: 10, background: "rgba(255,255,255,0.04)", borderRadius: 8 }}>
          <Avatar initials="AM" color="linear-gradient(135deg,#4f9cf9,#f472b6)" size={34} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#e8edf5" }}>Anaya Mehta</div>
            <div style={{ fontSize: 11, color: "#5a7090" }}>Special Educator</div>
          </div>
          <Settings size={14} style={{ color: "#5a7090", cursor: "pointer" }} />
        </div>
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════
// DASHBOARD VIEW
// ═══════════════════════════════════════════
const DashboardView = ({ students, messages, onNav }) => {
  const alerts = students.filter(s => s.riskLevel === "Critical" || s.riskLevel === "Moderate");
  const avgProgress = Math.round(students.reduce((a, s) => a + s.academicProgress, 0) / students.length);
  const avgAttendance = Math.round(students.reduce((a, s) => a + s.attendance, 0) / students.length);

  const disabilityData = [
    { name: "Visual", value: students.filter(s => s.disability === "Visual Impairment").length, color: "#4f9cf9" },
    { name: "Hearing", value: students.filter(s => s.disability === "Hearing Impairment").length, color: "#7c6ff7" },
    { name: "Autism", value: students.filter(s => s.disability === "Autism Spectrum").length, color: "#f59e0b" },
    { name: "Dyslexia", value: students.filter(s => s.disability === "Dyslexia").length, color: "#f472b6" },
    { name: "Physical", value: students.filter(s => s.disability === "Physical Disability").length, color: "#2dd4bf" },
  ];

  const overallProgress = [
    { month: "Aug", academic: 45, therapy: 50 }, { month: "Sep", academic: 51, therapy: 57 },
    { month: "Oct", academic: 57, therapy: 63 }, { month: "Nov", academic: 63, therapy: 69 },
    { month: "Dec", academic: 65, therapy: 71 }, { month: "Jan", academic: 67, therapy: 73 },
    { month: "Feb", academic: 70, therapy: 76 },
  ];

  const holistic = [
    { metric: "Academic", value: avgProgress }, { metric: "Social", value: 62 },
    { metric: "Emotional", value: 69 }, { metric: "Self-Care", value: 66 },
    { metric: "Therapy", value: 73 }, { metric: "Attendance", value: avgAttendance },
  ];

  return (
    <div>
      {/* Welcome banner */}
      <div style={{
        background: "linear-gradient(135deg,rgba(79,156,249,0.1),rgba(124,111,247,0.08),rgba(45,212,191,0.05))",
        border: "1px solid rgba(79,156,249,0.2)", borderRadius: 16, padding: "24px 28px",
        marginBottom: 24, display: "flex", alignItems: "center", justifyContent: "space-between",
        position: "relative", overflow: "hidden"
      }}>
        <div style={{ position: "absolute", top: "-50%", right: "-5%", width: 300, height: 300, background: "radial-gradient(circle,rgba(124,111,247,0.12) 0%,transparent 70%)", pointerEvents: "none" }} />
        <div>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 26, fontWeight: 700, color: "#e8edf5", marginBottom: 4 }}>
            Good morning, <span style={{ color: "#4f9cf9", fontStyle: "italic" }}>Anaya</span> 👋
          </div>
          <div style={{ fontSize: 14, color: "#8fa3bf" }}>
            {alerts.length} risk alerts active · {messages.filter(m => m.unread).length} unread messages · Feb 20, 2026
          </div>
        </div>
        <div style={{ display: "flex", gap: 28, flexShrink: 0 }}>
          {[
            { val: students.length, label: "Students", color: "#4f9cf9" },
            { val: `${avgProgress}%`, label: "Avg Progress", color: "#3ecf8e" },
            { val: alerts.length, label: "Risk Alerts", color: "#f59e0b" }
          ].map(s => (
            <div key={s.label} style={{ textAlign: "center" }}>
              <div style={{ fontFamily: "'Fraunces', serif", fontSize: 28, fontWeight: 700, color: s.color }}>{s.val}</div>
              <div style={{ fontSize: 11, color: "#5a7090" }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* KPI Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 20 }}>
        {[
          { label: "Total Students", val: students.length, sub: "+8 this month", subColor: "#3ecf8e", icon: <Users size={18} />, accent: "#4f9cf9", top: "#4f9cf9" },
          { label: "Active ILPs", val: students.length, sub: "All updated", subColor: "#3ecf8e", icon: <BookOpen size={18} />, accent: "#3ecf8e", top: "#3ecf8e" },
          { label: "Therapy Sessions", val: 48, sub: "This week", subColor: "#8fa3bf", icon: <Brain size={18} />, accent: "#f59e0b", top: "#f59e0b" },
          { label: "Risk Alerts", val: alerts.length, sub: "Needs attention", subColor: "#f87171", icon: <AlertTriangle size={18} />, accent: "#f87171", top: "#f87171" }
        ].map(k => (
          <Card key={k.label} style={{ borderTop: `3px solid ${k.top}`, position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", top: 12, right: 12, width: 36, height: 36, borderRadius: 9, background: `${k.accent}20`, display: "flex", alignItems: "center", justifyContent: "center", color: k.accent }}>{k.icon}</div>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#5a7090", letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: 6 }}>{k.label}</div>
            <div style={{ fontFamily: "'Fraunces', serif", fontSize: 36, fontWeight: 700, color: "#e8edf5", lineHeight: 1 }}>{k.val}</div>
            <div style={{ fontSize: 12, color: k.subColor, marginTop: 6 }}>{k.sub}</div>
          </Card>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 16, marginBottom: 16 }}>
        {/* Progress chart */}
        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <div style={{ fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 700, color: "#e8edf5" }}>Learning <span style={{ color: "#4f9cf9" }}>Outcomes</span></div>
            <Tag color="blue">6 Months</Tag>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={overallProgress}>
              <defs>
                <linearGradient id="gAcad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4f9cf9" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#4f9cf9" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gTher" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3ecf8e" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#3ecf8e" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="month" tick={{ fill: "#5a7090", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#5a7090", fontSize: 11 }} axisLine={false} tickLine={false} domain={[0, 100]} />
              <Tooltip contentStyle={{ background: "#1a2235", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#e8edf5" }} />
              <Area type="monotone" dataKey="academic" stroke="#4f9cf9" strokeWidth={2.5} fill="url(#gAcad)" name="Academic Progress" />
              <Area type="monotone" dataKey="therapy" stroke="#3ecf8e" strokeWidth={2.5} fill="url(#gTher)" strokeDasharray="4 3" name="Therapy Impact" />
              <Legend wrapperStyle={{ fontSize: 12, color: "#8fa3bf" }} />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        {/* Alerts */}
        <Card>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <div style={{ fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 700, color: "#e8edf5" }}>Risk <span style={{ color: "#f87171" }}>Alerts</span></div>
            <Tag color="red">{alerts.length} Active</Tag>
          </div>
          {alerts.map(s => (
            <div key={s.id} style={{
              display: "flex", gap: 10, padding: "12px 14px", borderRadius: 8,
              background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)",
              marginBottom: 8, alignItems: "flex-start"
            }}>
              <div style={{
                width: 9, height: 9, borderRadius: "50%",
                background: s.riskLevel === "Critical" ? "#f87171" : "#f59e0b",
                boxShadow: `0 0 8px ${s.riskLevel === "Critical" ? "#f87171" : "#f59e0b"}`,
                marginTop: 4, flexShrink: 0
              }} />
              <div>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#e8edf5" }}>{s.name} — <RiskBadge level={s.riskLevel} /></div>
                <div style={{ fontSize: 11, color: "#5a7090", marginTop: 3 }}>
                  {s.riskLevel === "Critical" ? `No progress logged in 14 days · Attendance: ${s.attendance}%` : `ILP review due · Therapy missed · Attendance: ${s.attendance}%`}
                </div>
              </div>
            </div>
          ))}
          <Btn variant="ghost" size="sm" onClick={() => onNav("students")} style={{ width: "100%", marginTop: 4, justifyContent: "center" }}>
            View All Students <ChevronRight size={13} />
          </Btn>
        </Card>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {/* Disability Distribution */}
        <Card>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 700, color: "#e8edf5", marginBottom: 16 }}>Disability <span style={{ color: "#4f9cf9" }}>Distribution</span></div>
          <div style={{ display: "flex", gap: 20, alignItems: "center" }}>
            <ResponsiveContainer width={140} height={140}>
              <PieChart>
                <Pie data={disabilityData} cx="50%" cy="50%" innerRadius={42} outerRadius={65} dataKey="value" strokeWidth={2} stroke="#0a0f1a">
                  {disabilityData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
                <Tooltip contentStyle={{ background: "#1a2235", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#e8edf5", fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
            <div style={{ flex: 1 }}>
              {disabilityData.map(d => (
                <div key={d.name} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                  <div style={{ width: 10, height: 10, borderRadius: 2, background: d.color, flexShrink: 0 }} />
                  <div style={{ flex: 1, fontSize: 12, color: "#8fa3bf" }}>{d.name}</div>
                  <div style={{ fontSize: 12, fontWeight: 700, color: "#e8edf5" }}>{d.value}</div>
                  <div style={{ width: 60 }}><ProgressBar value={(d.value / students.length) * 100} color={d.color} height={4} /></div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Holistic Radar */}
        <Card>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 700, color: "#e8edf5", marginBottom: 16 }}>Holistic <span style={{ color: "#3ecf8e" }}>Outcomes</span></div>
          <ResponsiveContainer width="100%" height={180}>
            <RadarChart data={holistic}>
              <PolarGrid stroke="rgba(255,255,255,0.08)" />
              <PolarAngleAxis dataKey="metric" tick={{ fill: "#8fa3bf", fontSize: 11 }} />
              <Radar name="Score" dataKey="value" stroke="#4f9cf9" fill="#4f9cf9" fillOpacity={0.2} strokeWidth={2} />
              <Tooltip contentStyle={{ background: "#1a2235", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#e8edf5", fontSize: 12 }} />
            </RadarChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════
// STUDENTS VIEW
// ═══════════════════════════════════════════
const StudentsView = ({ students, onAddStudent, onSelectStudent }) => {
  const [search, setSearch] = useState("");
  const [filterDisability, setFilterDisability] = useState("All");
  const [filterRisk, setFilterRisk] = useState("All");
  const [showAdd, setShowAdd] = useState(false);
  const [newStudent, setNewStudent] = useState({ name: "", age: "", grade: "Grade 5", disability: "Visual Impairment", severity: "Moderate", goals: "", parentContact: "" });
  const [sortBy, setSortBy] = useState("name");

  const disabilities = ["All", ...new Set(students.map(s => s.disability))];
  const risks = ["All", "Critical", "Moderate", "Low", "Minimal"];

  const filtered = students
    .filter(s => s.name.toLowerCase().includes(search.toLowerCase()) || s.id.toLowerCase().includes(search.toLowerCase()))
    .filter(s => filterDisability === "All" || s.disability === filterDisability)
    .filter(s => filterRisk === "All" || s.riskLevel === filterRisk)
    .sort((a, b) => {
      if (sortBy === "name") return a.name.localeCompare(b.name);
      if (sortBy === "progress") return b.academicProgress - a.academicProgress;
      if (sortBy === "risk") return ["Critical", "Moderate", "Low", "Minimal"].indexOf(a.riskLevel) - ["Critical", "Moderate", "Low", "Minimal"].indexOf(b.riskLevel);
      return 0;
    });

  const handleAdd = () => {
    if (!newStudent.name || !newStudent.age) return;
    const colors = ["#4f9cf9", "#3ecf8e", "#7c6ff7", "#f87171", "#fb923c", "#2dd4bf"];
    const color = colors[students.length % colors.length];
    const initials = newStudent.name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
    onAddStudent({
      ...newStudent, id: `STU-${String(students.length + 1).padStart(3, "0")}`,
      avatar: initials, color, bg: "linear-gradient(135deg,#1a2235,#111827)",
      academicProgress: 0, therapyEngagement: 0, attendance: 0,
      socialScore: 0, emotionalScore: 0, selfScore: 0,
      riskLevel: "Low", trend: "stable",
      therapist: "Unassigned", therapistType: "",
      contentMode: "Standard", joinDate: new Date().toISOString().slice(0, 10),
      milestones: [], monthlyProgress: [], therapyLogs: [],
      accommodations: []
    });
    setNewStudent({ name: "", age: "", grade: "Grade 5", disability: "Visual Impairment", severity: "Moderate", goals: "", parentContact: "" });
    setShowAdd(false);
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div style={{ fontFamily: "'Fraunces', serif", fontSize: 22, fontWeight: 700, color: "#e8edf5" }}>
          Student <span style={{ color: "#4f9cf9" }}>Profiles</span>
          <span style={{ fontSize: 14, fontWeight: 400, color: "#5a7090", marginLeft: 10, fontFamily: "'DM Sans', sans-serif" }}>{filtered.length} students</span>
        </div>
        <Btn onClick={() => setShowAdd(true)}><UserPlus size={15} /> Add Student</Btn>
      </div>

      {/* Filters */}
      <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap", alignItems: "center" }}>
        <div style={{ position: "relative", flex: 1, minWidth: 200, maxWidth: 300 }}>
          <Search size={14} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "#5a7090" }} />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search students..."
            style={{ width: "100%", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.09)", borderRadius: 8, padding: "9px 12px 9px 34px", color: "#e8edf5", fontFamily: "'DM Sans', sans-serif", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
        </div>
        <FormSelect label="" value={filterDisability} onChange={setFilterDisability} options={disabilities} />
        <FormSelect label="" value={filterRisk} onChange={setFilterRisk} options={risks} />
        <FormSelect label="" value={sortBy} onChange={setSortBy} options={[{ value: "name", label: "Sort: Name" }, { value: "progress", label: "Sort: Progress" }, { value: "risk", label: "Sort: Risk" }]} />
      </div>

      {/* Student Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16 }}>
        {filtered.map(s => (
          <div key={s.id} onClick={() => onSelectStudent(s)} style={{
            background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: 14, overflow: "hidden", cursor: "pointer",
            transition: "all 0.25s"
          }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.15)"; e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 8px 30px rgba(0,0,0,0.3)"; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)"; e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = ""; }}
          >
            <div style={{ height: 60, background: s.bg, position: "relative" }}>
              <div style={{ position: "absolute", top: 10, right: 10 }}><RiskBadge level={s.riskLevel} /></div>
            </div>
            <div style={{ padding: "0 16px 16px" }}>
              <div style={{ marginTop: -20, marginBottom: 10 }}>
                <div style={{ width: 44, height: 44, borderRadius: "50%", background: s.color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, fontWeight: 700, color: "#fff", border: "3px solid #111827" }}>{s.avatar}</div>
              </div>
              <div style={{ fontSize: 15, fontWeight: 700, color: "#e8edf5" }}>{s.name}</div>
              <div style={{ fontSize: 12, color: "#5a7090", marginBottom: 10 }}>{s.id} · {s.grade} · Age {s.age}</div>
              <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginBottom: 12 }}>
                <Tag color={s.disability.includes("Visual") ? "blue" : s.disability.includes("Hearing") ? "purple" : s.disability.includes("Autism") ? "amber" : s.disability.includes("Dyslexia") ? "pink" : "teal"}>
                  {s.disability}
                </Tag>
              </div>
              <div style={{ marginBottom: 8 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#8fa3bf", marginBottom: 4 }}>
                  <span>Academic Progress</span><span style={{ fontWeight: 700, color: "#e8edf5" }}>{s.academicProgress}%</span>
                </div>
                <ProgressBar value={s.academicProgress} color={s.academicProgress < 50 ? "#f87171" : s.academicProgress < 70 ? "#f59e0b" : "#3ecf8e"} />
              </div>
              <div style={{ marginBottom: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#8fa3bf", marginBottom: 4 }}>
                  <span>Therapy Engagement</span><span style={{ fontWeight: 700, color: "#e8edf5" }}>{s.therapyEngagement}%</span>
                </div>
                <ProgressBar value={s.therapyEngagement} color="#7c6ff7" />
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "#5a7090" }}>
                <TrendIcon trend={s.trend} />
                <span>Attend: <span style={{ color: s.attendance < 60 ? "#f87171" : "#e8edf5", fontWeight: 600 }}>{s.attendance}%</span></span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Student Modal */}
      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Add New Student">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 16px" }}>
          <FormInput label="Full Name" value={newStudent.name} onChange={v => setNewStudent({ ...newStudent, name: v })} placeholder="Enter full name" required />
          <FormInput label="Age" type="number" value={newStudent.age} onChange={v => setNewStudent({ ...newStudent, age: v })} placeholder="e.g. 12" required />
          <FormSelect label="Grade" value={newStudent.grade} onChange={v => setNewStudent({ ...newStudent, grade: v })} options={["Grade 1","Grade 2","Grade 3","Grade 4","Grade 5","Grade 6","Grade 7","Grade 8","Grade 9","Grade 10"]} />
          <FormSelect label="Severity" value={newStudent.severity} onChange={v => setNewStudent({ ...newStudent, severity: v })} options={["Mild","Moderate","Severe"]} />
        </div>
        <FormSelect label="Disability Type" value={newStudent.disability} onChange={v => setNewStudent({ ...newStudent, disability: v })} required
          options={["Visual Impairment","Hearing Impairment","Autism Spectrum","Dyslexia","Physical Disability","Intellectual Disability","Multiple Disabilities","Other"]} />
        <FormTextarea label="Primary Support Goals" value={newStudent.goals} onChange={v => setNewStudent({ ...newStudent, goals: v })} placeholder="Describe specific learning needs and goals..." rows={3} />
        <FormInput label="Parent / Guardian Contact" value={newStudent.parentContact} onChange={v => setNewStudent({ ...newStudent, parentContact: v })} placeholder="Name | Phone number" />
        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 8 }}>
          <Btn variant="ghost" onClick={() => setShowAdd(false)}>Cancel</Btn>
          <Btn onClick={handleAdd} disabled={!newStudent.name || !newStudent.age}><Check size={14} /> Save Student</Btn>
        </div>
      </Modal>
    </div>
  );
};

// ═══════════════════════════════════════════
// STUDENT DETAIL PANEL
// ═══════════════════════════════════════════
const StudentDetail = ({ student, onBack, onUpdate }) => {
  const [tab, setTab] = useState("overview");
  const [editGoals, setEditGoals] = useState(false);
  const [goals, setGoals] = useState(student.goals);
  const [progress, setProgress] = useState({ academic: student.academicProgress, therapy: student.therapyEngagement, attendance: student.attendance });
  const [editProgress, setEditProgress] = useState(false);

  const tabs = ["overview", "progress", "milestones", "therapy", "accommodations"];

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
        <Btn variant="ghost" size="sm" onClick={onBack}><ChevronRight size={14} style={{ transform: "rotate(180deg)" }} /> Students</Btn>
        <ChevronRight size={14} style={{ color: "#5a7090" }} />
        <span style={{ color: "#e8edf5", fontWeight: 600 }}>{student.name}</span>
      </div>

      {/* Header */}
      <div style={{ background: student.bg, borderRadius: 16, padding: 24, marginBottom: 20, position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.3)" }} />
        <div style={{ position: "relative", display: "flex", gap: 16, alignItems: "flex-start" }}>
          <div style={{ width: 64, height: 64, borderRadius: "50%", background: student.color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, fontWeight: 700, color: "#fff", border: "3px solid rgba(255,255,255,0.2)", flexShrink: 0 }}>{student.avatar}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: "'Fraunces', serif", fontSize: 24, fontWeight: 700, color: "#fff" }}>{student.name}</div>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", marginBottom: 10 }}>{student.id} · {student.grade} · Age {student.age} · Joined {student.joinDate}</div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <Tag color="blue">{student.disability}</Tag>
              <Tag color="gray">{student.severity} Severity</Tag>
              <RiskBadge level={student.riskLevel} />
              <Tag color={student.trend === "excellent" || student.trend === "improving" ? "green" : student.trend === "declining" ? "red" : "gray"}>
                <TrendIcon trend={student.trend} />
              </Tag>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            {[
              { label: `${student.academicProgress}%`, sub: "Academic", color: "#4f9cf9" },
              { label: `${student.therapyEngagement}%`, sub: "Therapy", color: "#3ecf8e" },
              { label: `${student.attendance}%`, sub: "Attendance", color: student.attendance < 60 ? "#f87171" : "#f59e0b" }
            ].map(k => (
              <div key={k.sub} style={{ textAlign: "center", padding: "10px 14px", background: "rgba(0,0,0,0.3)", borderRadius: 10, backdropFilter: "blur(4px)" }}>
                <div style={{ fontFamily: "'Fraunces', serif", fontSize: 22, fontWeight: 700, color: k.color }}>{k.label}</div>
                <div style={{ fontSize: 10, color: "rgba(255,255,255,0.6)" }}>{k.sub}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 4, marginBottom: 16, background: "rgba(255,255,255,0.03)", borderRadius: 10, padding: 4 }}>
        {tabs.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            flex: 1, padding: "8px 0", borderRadius: 7, border: "none",
            background: tab === t ? "rgba(79,156,249,0.2)" : "transparent",
            color: tab === t ? "#4f9cf9" : "#8fa3bf", fontSize: 12, fontWeight: 600,
            cursor: "pointer", transition: "all 0.2s", textTransform: "capitalize",
            fontFamily: "'DM Sans', sans-serif"
          }}>{t}</button>
        ))}
      </div>

      {tab === "overview" && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          <Card>
            <div style={{ fontSize: 14, fontWeight: 700, color: "#e8edf5", marginBottom: 12 }}>Student Information</div>
            {[
              { label: "Therapist", val: student.therapist },
              { label: "Therapist Type", val: student.therapistType },
              { label: "Content Mode", val: student.contentMode },
              { label: "Parent Contact", val: student.parentContact },
            ].map(r => (
              <div key={r.label} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid rgba(255,255,255,0.06)", fontSize: 13 }}>
                <span style={{ color: "#5a7090" }}>{r.label}</span>
                <span style={{ color: "#e8edf5", fontWeight: 500 }}>{r.val}</span>
              </div>
            ))}
          </Card>
          <Card>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "#e8edf5" }}>Learning Goals</div>
              <Btn variant="ghost" size="sm" onClick={() => setEditGoals(!editGoals)}><Edit size={12} /> {editGoals ? "Cancel" : "Edit"}</Btn>
            </div>
            {editGoals ? (
              <div>
                <FormTextarea label="" value={goals} onChange={setGoals} rows={4} />
                <Btn size="sm" onClick={() => { onUpdate(student.id, { goals }); setEditGoals(false); }}><Save size={12} /> Save Goals</Btn>
              </div>
            ) : (
              <div style={{ fontSize: 13, color: "#8fa3bf", lineHeight: 1.7 }}>{goals}</div>
            )}
          </Card>
          <Card style={{ gridColumn: "1/-1" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "#e8edf5" }}>Update Progress Metrics</div>
              <Btn variant="ghost" size="sm" onClick={() => setEditProgress(!editProgress)}>{editProgress ? <X size={12} /> : <Edit size={12} />} {editProgress ? "Cancel" : "Update"}</Btn>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16 }}>
              {[
                { key: "academic", label: "Academic Progress", color: "#4f9cf9" },
                { key: "therapy", label: "Therapy Engagement", color: "#3ecf8e" },
                { key: "attendance", label: "Attendance", color: "#f59e0b" }
              ].map(m => (
                <div key={m.key}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "#8fa3bf", marginBottom: 6 }}>
                    <span>{m.label}</span><span style={{ fontWeight: 700, color: "#e8edf5" }}>{progress[m.key]}%</span>
                  </div>
                  {editProgress ? (
                    <input type="range" min="0" max="100" value={progress[m.key]} onChange={e => setProgress({ ...progress, [m.key]: +e.target.value })}
                      style={{ width: "100%", accentColor: m.color }} />
                  ) : (
                    <ProgressBar value={progress[m.key]} color={m.color} />
                  )}
                </div>
              ))}
            </div>
            {editProgress && (
              <Btn size="sm" style={{ marginTop: 12 }} onClick={() => {
                onUpdate(student.id, { academicProgress: progress.academic, therapyEngagement: progress.therapy, attendance: progress.attendance });
                setEditProgress(false);
              }}><Save size={12} /> Save Progress</Btn>
            )}
          </Card>
        </div>
      )}

      {tab === "progress" && (
        <Card>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 700, color: "#e8edf5", marginBottom: 16 }}>6-Month Progress Chart</div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={student.monthlyProgress}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="month" tick={{ fill: "#5a7090", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#5a7090", fontSize: 11 }} axisLine={false} tickLine={false} domain={[0, 100]} />
              <Tooltip contentStyle={{ background: "#1a2235", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#e8edf5" }} />
              <Legend wrapperStyle={{ fontSize: 12, color: "#8fa3bf" }} />
              <Line type="monotone" dataKey="academic" stroke={student.color} strokeWidth={2.5} dot={{ fill: student.color, r: 5 }} name="Academic Progress" />
              <Line type="monotone" dataKey="therapy" stroke="#3ecf8e" strokeWidth={2.5} strokeDasharray="4 3" dot={{ fill: "#3ecf8e", r: 4 }} name="Therapy Engagement" />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      )}

      {tab === "milestones" && (
        <Card>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 700, color: "#e8edf5", marginBottom: 4 }}>Learning Milestones</div>
          <div style={{ fontSize: 12, color: "#5a7090", marginBottom: 16 }}>{student.milestones.filter(m => m.done).length} of {student.milestones.length} completed</div>
          <ProgressBar value={student.milestones.length ? (student.milestones.filter(m => m.done).length / student.milestones.length) * 100 : 0} color={student.color} height={8} />
          <div style={{ marginTop: 16, display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 8 }}>
            {student.milestones.map((m, i) => (
              <div key={i} style={{
                display: "flex", alignItems: "center", gap: 10, padding: "10px 14px",
                background: m.done ? "rgba(62,207,142,0.08)" : "rgba(255,255,255,0.03)",
                border: `1px solid ${m.done ? "rgba(62,207,142,0.2)" : "rgba(255,255,255,0.07)"}`,
                borderRadius: 8
              }}>
                <div style={{ width: 22, height: 22, borderRadius: "50%", background: m.done ? "#3ecf8e" : "rgba(255,255,255,0.08)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  {m.done ? <Check size={12} color="#fff" /> : <span style={{ fontSize: 11, color: "#5a7090" }}>{i + 1}</span>}
                </div>
                <span style={{ fontSize: 13, color: m.done ? "#e8edf5" : "#5a7090", fontWeight: m.done ? 600 : 400 }}>{m.name}</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      {tab === "therapy" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {student.therapyLogs.length === 0 && <Card><div style={{ color: "#5a7090", textAlign: "center", padding: 20 }}>No therapy sessions logged yet.</div></Card>}
          {student.therapyLogs.map((log, i) => (
            <Card key={i}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 14, color: "#e8edf5" }}>{log.type}</div>
                  <div style={{ fontSize: 12, color: "#5a7090" }}>{log.date} · {log.therapist} · {log.duration} min</div>
                </div>
                <Tag color={log.outcome === "Excellent" ? "green" : log.outcome === "Good" ? "blue" : "amber"}>{log.outcome}</Tag>
              </div>
              <div style={{ fontSize: 13, color: "#8fa3bf", lineHeight: 1.6, marginBottom: 10 }}>{log.notes}</div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {log.resources.map(r => <Tag key={r} color="purple">{r}</Tag>)}
              </div>
            </Card>
          ))}
        </div>
      )}

      {tab === "accommodations" && (
        <Card>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 700, color: "#e8edf5", marginBottom: 16 }}>Active Accommodations</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {student.accommodations.map((a, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 16px", background: "rgba(79,156,249,0.06)", border: "1px solid rgba(79,156,249,0.15)", borderRadius: 8 }}>
                <CheckCircle size={16} style={{ color: "#4f9cf9", flexShrink: 0 }} />
                <span style={{ fontSize: 13, color: "#e8edf5" }}>{a}</span>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};

// ═══════════════════════════════════════════
// LEARNING PLANS VIEW
// ═══════════════════════════════════════════
const LearningPlansView = ({ students, onUpdate, showToast }) => {
  const [showAdd, setShowAdd] = useState(false);
  const [selected, setSelected] = useState(students[0]?.id || "");
  const [mode, setMode] = useState("Audio-First");
  const [planGoals, setPlanGoals] = useState("");
  const [reviewDate, setReviewDate] = useState("");
  const [aiLoading, setAiLoading] = useState(null);

  const contentModeColor = m => ({ "Audio-First": "teal", "Structured Modules": "purple", "Sign + Subtitles": "blue", "Simplified Visual": "pink", "Standard + Adaptive": "green" })[m] || "gray";

  const handleSavePlan = () => {
    showToast("Learning plan updated successfully!", "success");
    setShowAdd(false);
  };

  const runAI = (studentId) => {
    setAiLoading(studentId);
    setTimeout(() => setAiLoading(null), 1800);
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div style={{ fontFamily: "'Fraunces', serif", fontSize: 22, fontWeight: 700, color: "#e8edf5" }}>
          Individualized <span style={{ color: "#4f9cf9" }}>Learning Plans</span>
        </div>
        <Btn onClick={() => setShowAdd(true)}><Plus size={15} /> New ILP</Btn>
      </div>

      {/* ILP Table */}
      <Card style={{ padding: 0, marginBottom: 16 }}>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
                {["Student", "Disability", "Content Mode", "Milestones", "Progress", "Last Updated", "Status", "Actions"].map(h => (
                  <th key={h} style={{ textAlign: "left", padding: "12px 16px", fontSize: 10, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", color: "#5a7090", background: "rgba(255,255,255,0.02)", whiteSpace: "nowrap" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {students.map(s => {
                const done = s.milestones.filter(m => m.done).length;
                const total = s.milestones.length;
                return (
                  <tr key={s.id} style={{ borderBottom: "1px solid rgba(255,255,255,0.05)", transition: "background 0.15s" }}
                    onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,0.02)"}
                    onMouseLeave={e => e.currentTarget.style.background = ""}
                  >
                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <Avatar initials={s.avatar} color={s.color} size={32} />
                        <div>
                          <div style={{ fontSize: 13, fontWeight: 700, color: "#e8edf5" }}>{s.name}</div>
                          <div style={{ fontSize: 11, color: "#5a7090", fontFamily: "'DM Mono', monospace" }}>{s.id}</div>
                        </div>
                      </div>
                    </td>
                    <td style={{ padding: "14px 16px" }}><Tag color={s.disability.includes("Visual") ? "blue" : s.disability.includes("Hearing") ? "purple" : s.disability.includes("Autism") ? "amber" : s.disability.includes("Dyslexia") ? "pink" : "teal"}>{s.disability}</Tag></td>
                    <td style={{ padding: "14px 16px" }}><Tag color={contentModeColor(s.contentMode)}>{s.contentMode}</Tag></td>
                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ fontSize: 12, color: "#8fa3bf" }}>{done}/{total}</div>
                      <ProgressBar value={total ? (done / total) * 100 : 0} color={s.color} height={4} />
                    </td>
                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ width: 100 }}><ProgressBar value={s.academicProgress} color={s.academicProgress < 50 ? "#f87171" : s.academicProgress < 70 ? "#f59e0b" : "#3ecf8e"} /></div>
                      <div style={{ fontSize: 11, color: "#5a7090", marginTop: 3 }}>{s.academicProgress}%</div>
                    </td>
                    <td style={{ padding: "14px 16px", fontSize: 12, color: "#5a7090" }}>Feb 20, 2026</td>
                    <td style={{ padding: "14px 16px" }}><RiskBadge level={s.riskLevel} /></td>
                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ display: "flex", gap: 6 }}>
                        <Btn variant="ghost" size="sm" onClick={() => runAI(s.id)} style={{ fontSize: 11 }}>
                          {aiLoading === s.id ? <RefreshCw size={12} style={{ animation: "spin 1s linear infinite" }} /> : <Sparkles size={12} />} AI
                        </Btn>
                        <Btn variant="ghost" size="sm" style={{ fontSize: 11 }}><Edit size={12} /></Btn>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* AI Recommendations */}
      <Card style={{ border: "1px solid rgba(124,111,247,0.3)", background: "linear-gradient(135deg,rgba(124,111,247,0.06),rgba(79,156,249,0.04))" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
          <Sparkles size={22} style={{ color: "#7c6ff7" }} />
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: "#e8edf5" }}>AI Learning Plan Recommendations</div>
            <div style={{ fontSize: 12, color: "#5a7090" }}>Powered by InclusaLearn ML Engine · 92% avg accuracy</div>
          </div>
          <Tag color="purple" style={{ marginLeft: "auto" }}>Live Analysis</Tag>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12 }}>
          {students.slice(0, 3).map(s => {
            const recs = AI_RECOMMENDATIONS[s.id];
            if (!recs) return null;
            return (
              <div key={s.id} style={{ padding: 14, background: "rgba(255,255,255,0.04)", borderRadius: 10, border: "1px solid rgba(255,255,255,0.08)" }}>
                <div style={{ fontSize: 11, color: "#5a7090", marginBottom: 4 }}>For {s.name}</div>
                <div style={{ fontSize: 13, fontWeight: 700, color: "#e8edf5", marginBottom: 6 }}>{recs[0].title}</div>
                <div style={{ fontSize: 12, color: "#8fa3bf", marginBottom: 8, lineHeight: 1.5 }}>{recs[0].detail}</div>
                <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                  <Tag color="blue">Confidence: {recs[0].confidence}%</Tag>
                  <Tag color="purple">{recs[0].tag}</Tag>
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* New ILP Modal */}
      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Create Learning Plan">
        <FormSelect label="Student" value={selected} onChange={setSelected} options={students.map(s => ({ value: s.id, label: `${s.name} (${s.id})` }))} required />
        <FormSelect label="Content Delivery Mode" value={mode} onChange={setMode} options={["Audio-First", "Structured Modules", "Sign + Subtitles", "Simplified Visual", "Standard + Adaptive"]} />
        <FormTextarea label="Learning Goals (This Semester)" value={planGoals} onChange={setPlanGoals} placeholder="Describe specific, measurable learning goals..." />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 16px" }}>
          <FormInput label="Start Date" type="date" value="" onChange={() => {}} />
          <FormInput label="Review Date" type="date" value={reviewDate} onChange={setReviewDate} />
        </div>
        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 8 }}>
          <Btn variant="ghost" onClick={() => setShowAdd(false)}>Cancel</Btn>
          <Btn onClick={handleSavePlan}><Check size={14} /> Create Plan</Btn>
        </div>
      </Modal>
    </div>
  );
};

// ═══════════════════════════════════════════
// PROGRESS TRACKING VIEW
// ═══════════════════════════════════════════
const ProgressView = ({ students }) => {
  const avgAcad = Math.round(students.reduce((a, s) => a + s.academicProgress, 0) / students.length);
  const avgTher = Math.round(students.reduce((a, s) => a + s.therapyEngagement, 0) / students.length);
  const avgAtt = Math.round(students.reduce((a, s) => a + s.attendance, 0) / students.length);

  const holistic = [
    { metric: "Communication", value: 74 }, { metric: "Social", value: 61 },
    { metric: "Self-Sufficiency", value: 82 }, { metric: "Sensory Reg", value: 55 },
    { metric: "Academic Lit", value: 69 }, { metric: "Emotional", value: 78 }
  ];

  const barData = students.map(s => ({ name: s.name.split(" ")[0], academic: s.academicProgress, therapy: s.therapyEngagement }));

  return (
    <div>
      <div style={{ fontFamily: "'Fraunces', serif", fontSize: 22, fontWeight: 700, color: "#e8edf5", marginBottom: 20 }}>
        Progress <span style={{ color: "#4f9cf9" }}>Tracking</span>
      </div>

      {/* KPI row */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 20 }}>
        {[
          { label: "Avg Academic", val: `${avgAcad}%`, color: "#4f9cf9", sub: "↑ 4% vs last month", subColor: "#3ecf8e" },
          { label: "Avg Therapy", val: `${avgTher}%`, color: "#3ecf8e", sub: "↑ 6% improvement", subColor: "#3ecf8e" },
          { label: "Milestone Rate", val: "72%", color: "#f59e0b", sub: "This quarter", subColor: "#8fa3bf" },
          { label: "Avg Attendance", val: `${avgAtt}%`, color: "#7c6ff7", sub: "↓ 2% this week", subColor: "#f87171" }
        ].map(k => (
          <Card key={k.label} style={{ borderTop: `3px solid ${k.color}` }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#5a7090", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 6 }}>{k.label}</div>
            <div style={{ fontFamily: "'Fraunces', serif", fontSize: 36, fontWeight: 700, color: k.color }}>{k.val}</div>
            <div style={{ fontSize: 12, color: k.subColor, marginTop: 4 }}>{k.sub}</div>
          </Card>
        ))}
      </div>

      {/* Charts row */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
        <Card>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 700, color: "#e8edf5", marginBottom: 16 }}>Student <span style={{ color: "#4f9cf9" }}>Comparison</span></div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={barData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="name" tick={{ fill: "#5a7090", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#5a7090", fontSize: 11 }} axisLine={false} tickLine={false} domain={[0, 100]} />
              <Tooltip contentStyle={{ background: "#1a2235", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#e8edf5" }} />
              <Legend wrapperStyle={{ fontSize: 12, color: "#8fa3bf" }} />
              <Bar dataKey="academic" fill="#4f9cf9" name="Academic" radius={[4, 4, 0, 0]} />
              <Bar dataKey="therapy" fill="#3ecf8e" name="Therapy" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 700, color: "#e8edf5", marginBottom: 16 }}>Holistic <span style={{ color: "#3ecf8e" }}>Outcomes</span></div>
          {holistic.map(h => (
            <div key={h.metric} style={{ marginBottom: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "#8fa3bf", marginBottom: 5 }}>
                <span>{h.metric}</span><span style={{ fontWeight: 700, color: "#e8edf5" }}>{h.value}%</span>
              </div>
              <ProgressBar value={h.value} color={h.value > 75 ? "#3ecf8e" : h.value > 55 ? "#4f9cf9" : "#f59e0b"} />
            </div>
          ))}
        </Card>
      </div>

      {/* Detail table */}
      <Card style={{ padding: 0 }}>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 700, color: "#e8edf5" }}>Student <span style={{ color: "#4f9cf9" }}>Detail</span></div>
        </div>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
              {["Student", "Disability", "Academic", "Therapy", "Social", "Attendance", "Trend", "Risk"].map(h => (
                <th key={h} style={{ textAlign: "left", padding: "10px 16px", fontSize: 10, fontWeight: 700, letterSpacing: "0.07em", textTransform: "uppercase", color: "#5a7090", background: "rgba(255,255,255,0.02)" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {students.map(s => (
              <tr key={s.id} style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}
                onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,0.02)"}
                onMouseLeave={e => e.currentTarget.style.background = ""}
              >
                <td style={{ padding: "12px 16px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <Avatar initials={s.avatar} color={s.color} size={28} />
                    <span style={{ fontSize: 13, fontWeight: 600, color: "#e8edf5" }}>{s.name}</span>
                  </div>
                </td>
                <td style={{ padding: "12px 16px" }}><Tag color={s.disability.includes("Visual") ? "blue" : s.disability.includes("Hearing") ? "purple" : s.disability.includes("Autism") ? "amber" : s.disability.includes("Dyslexia") ? "pink" : "teal"}>{s.disability.split(" ")[0]}</Tag></td>
                <td style={{ padding: "12px 16px" }}>
                  <div style={{ width: 80 }}><ProgressBar value={s.academicProgress} color="#4f9cf9" /></div>
                  <div style={{ fontSize: 11, color: "#5a7090", marginTop: 2 }}>{s.academicProgress}%</div>
                </td>
                <td style={{ padding: "12px 16px" }}>
                  <div style={{ width: 80 }}><ProgressBar value={s.therapyEngagement} color="#3ecf8e" /></div>
                  <div style={{ fontSize: 11, color: "#5a7090", marginTop: 2 }}>{s.therapyEngagement}%</div>
                </td>
                <td style={{ padding: "12px 16px" }}>
                  <div style={{ width: 80 }}><ProgressBar value={s.socialScore} color="#7c6ff7" /></div>
                  <div style={{ fontSize: 11, color: "#5a7090", marginTop: 2 }}>{s.socialScore}%</div>
                </td>
                <td style={{ padding: "12px 16px" }}><Tag color={s.attendance < 60 ? "red" : s.attendance < 80 ? "amber" : "green"}>{s.attendance}%</Tag></td>
                <td style={{ padding: "12px 16px" }}><TrendIcon trend={s.trend} /></td>
                <td style={{ padding: "12px 16px" }}><RiskBadge level={s.riskLevel} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
};

// ═══════════════════════════════════════════
// THERAPY LOGS VIEW
// ═══════════════════════════════════════════
const TherapyView = ({ students, onLogSession, showToast }) => {
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ studentId: students[0]?.id || "", type: "Speech Therapy", therapist: THERAPISTS[0].name, date: new Date().toISOString().slice(0, 10), duration: 45, notes: "", outcome: "Good", resources: [] });
  const allLogs = students.flatMap(s => s.therapyLogs.map(l => ({ ...l, student: s.name, studentId: s.id, avatar: s.avatar, color: s.color }))).sort((a, b) => b.date.localeCompare(a.date));
  const resourceOptions = ["Audio Device", "Braille Kit", "Sign Interpreter", "Sensory Tools", "AAC Device", "Emotion Cards", "Eye Tracker"];

  const toggleResource = r => setForm(f => ({ ...f, resources: f.resources.includes(r) ? f.resources.filter(x => x !== r) : [...f.resources, r] }));

  const handleLog = () => {
    const student = students.find(s => s.id === form.studentId);
    if (!student) return;
    onLogSession(form.studentId, { ...form });
    showToast(`Therapy session logged for ${student.name}`, "success");
    setShowAdd(false);
    setForm({ ...form, notes: "", resources: [] });
  };

  const outcomeColors = { Excellent: "green", Good: "blue", Moderate: "amber", Poor: "red" };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div style={{ fontFamily: "'Fraunces', serif", fontSize: 22, fontWeight: 700, color: "#e8edf5" }}>
          Therapy & Support <span style={{ color: "#3ecf8e" }}>Logs</span>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <Tag color="green">{allLogs.length} Total Sessions</Tag>
          <Btn onClick={() => setShowAdd(true)}><Plus size={15} /> Log Session</Btn>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 16 }}>
        {/* Timeline */}
        <div>
          <Card style={{ padding: 0 }}>
            <div style={{ padding: "16px 20px", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
              <div style={{ fontWeight: 700, color: "#e8edf5", fontSize: 15 }}>Session Timeline</div>
            </div>
            <div style={{ padding: "0 20px" }}>
              {allLogs.map((log, i) => (
                <div key={i} style={{ display: "flex", gap: 14, padding: "16px 0", borderBottom: i < allLogs.length - 1 ? "1px solid rgba(255,255,255,0.06)" : "none" }}>
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flexShrink: 0 }}>
                    <div style={{ width: 12, height: 12, borderRadius: "50%", background: log.outcome === "Excellent" ? "#3ecf8e" : log.outcome === "Good" ? "#4f9cf9" : "#f59e0b", boxShadow: `0 0 8px ${log.outcome === "Excellent" ? "#3ecf8e" : "#4f9cf9"}`, marginTop: 3 }} />
                    {i < allLogs.length - 1 && <div style={{ width: 2, flex: 1, background: "rgba(255,255,255,0.07)", marginTop: 6 }} />}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 13, color: "#e8edf5" }}>{log.type} — {log.student}</div>
                        <div style={{ fontSize: 11, color: "#5a7090", marginTop: 2 }}>{log.date} · {log.therapist} · {log.duration} min</div>
                      </div>
                      <Tag color={outcomeColors[log.outcome] || "gray"}>{log.outcome}</Tag>
                    </div>
                    <div style={{ fontSize: 12, color: "#8fa3bf", marginTop: 8, lineHeight: 1.6 }}>{log.notes}</div>
                    {log.resources.length > 0 && (
                      <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginTop: 8 }}>
                        {log.resources.map(r => <Tag key={r} color="purple">{r}</Tag>)}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Sidebar: Therapists + Stats */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <Card>
            <div style={{ fontWeight: 700, color: "#e8edf5", fontSize: 14, marginBottom: 14 }}>Support Specialists</div>
            {THERAPISTS.map(t => (
              <div key={t.id} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10, padding: "8px 10px", borderRadius: 8, background: "rgba(255,255,255,0.03)" }}>
                <Avatar initials={t.avatar} color={t.color} size={32} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: "#e8edf5" }}>{t.name}</div>
                  <div style={{ fontSize: 11, color: "#5a7090" }}>{t.role} · {t.students} students</div>
                </div>
                <Tag color={t.status === "Available" ? "green" : t.status === "In Session" ? "amber" : "gray"}>{t.status}</Tag>
              </div>
            ))}
          </Card>
          <Card>
            <div style={{ fontWeight: 700, color: "#e8edf5", fontSize: 14, marginBottom: 14 }}>Session Stats</div>
            {[
              { label: "This Week", val: "12" }, { label: "This Month", val: "48" },
              { label: "Avg Duration", val: "43 min" }, { label: "Completion Rate", val: "94%" }
            ].map(s => (
              <div key={s.label} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid rgba(255,255,255,0.06)", fontSize: 13 }}>
                <span style={{ color: "#5a7090" }}>{s.label}</span>
                <span style={{ color: "#e8edf5", fontWeight: 700 }}>{s.val}</span>
              </div>
            ))}
          </Card>
        </div>
      </div>

      {/* Log Session Modal */}
      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Log Therapy Session" width={580}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 16px" }}>
          <FormSelect label="Student" value={form.studentId} onChange={v => setForm({ ...form, studentId: v })} options={students.map(s => ({ value: s.id, label: s.name }))} required />
          <FormSelect label="Session Type" value={form.type} onChange={v => setForm({ ...form, type: v })} options={["Speech Therapy", "Occupational Therapy", "Psychological Support", "Physical Therapy", "Sign Language Session", "Educational Psychology"]} />
          <FormSelect label="Therapist" value={form.therapist} onChange={v => setForm({ ...form, therapist: v })} options={THERAPISTS.map(t => t.name)} />
          <FormInput label="Date" type="date" value={form.date} onChange={v => setForm({ ...form, date: v })} />
          <FormInput label="Duration (minutes)" type="number" value={form.duration} onChange={v => setForm({ ...form, duration: +v })} />
          <FormSelect label="Outcome" value={form.outcome} onChange={v => setForm({ ...form, outcome: v })} options={["Excellent", "Good", "Moderate", "Poor"]} />
        </div>
        <FormTextarea label="Session Notes" value={form.notes} onChange={v => setForm({ ...form, notes: v })} placeholder="Describe what was covered, student response, and next steps..." />
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#8fa3bf", marginBottom: 8, letterSpacing: "0.06em", textTransform: "uppercase" }}>Resources Used</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {resourceOptions.map(r => (
              <button key={r} onClick={() => toggleResource(r)} style={{
                padding: "5px 12px", borderRadius: 20, border: "1px solid",
                borderColor: form.resources.includes(r) ? "#7c6ff7" : "rgba(255,255,255,0.1)",
                background: form.resources.includes(r) ? "rgba(124,111,247,0.2)" : "transparent",
                color: form.resources.includes(r) ? "#7c6ff7" : "#8fa3bf",
                fontSize: 12, fontWeight: 600, cursor: "pointer", fontFamily: "'DM Sans', sans-serif"
              }}>{r}</button>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
          <Btn variant="ghost" onClick={() => setShowAdd(false)}>Cancel</Btn>
          <Btn onClick={handleLog} disabled={!form.notes}><Check size={14} /> Log Session</Btn>
        </div>
      </Modal>
    </div>
  );
};

// ═══════════════════════════════════════════
// COLLABORATION VIEW
// ═══════════════════════════════════════════
const CollaborationView = ({ messages, onAddMessage, onMarkRead, showToast }) => {
  const [selected, setSelected] = useState(messages[0]?.id || null);
  const [showCompose, setShowCompose] = useState(false);
  const [replyText, setReplyText] = useState("");
  const [form, setForm] = useState({ to: THERAPISTS[0].name, student: "", subject: "", body: "", priority: "Normal" });

  const selectedMsg = messages.find(m => m.id === selected);

  const handleReply = () => {
    if (!replyText.trim()) return;
    showToast("Reply sent successfully!", "success");
    setReplyText("");
  };

  const handleSend = () => {
    if (!form.subject || !form.body) return;
    onAddMessage({ ...form, id: Date.now(), from: "Anaya Mehta", fromRole: "Special Educator", avatar: "AM", color: "#3ecf8e", time: "Just now", replies: 0, unread: false });
    showToast("Message sent!", "success");
    setShowCompose(false);
    setForm({ to: THERAPISTS[0].name, student: "", subject: "", body: "", priority: "Normal" });
  };

  const priorityColor = p => ({ Normal: "blue", Urgent: "red", "For Review": "amber" })[p] || "gray";

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div style={{ fontFamily: "'Fraunces', serif", fontSize: 22, fontWeight: 700, color: "#e8edf5" }}>
          Team <span style={{ color: "#4f9cf9" }}>Collaboration</span>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <Tag color="red">{messages.filter(m => m.unread).length} unread</Tag>
          <Btn onClick={() => setShowCompose(true)}><Send size={15} /> Compose</Btn>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 16 }}>
        {/* Message list */}
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {messages.map(msg => (
            <div key={msg.id} onClick={() => { setSelected(msg.id); onMarkRead(msg.id); }} style={{
              padding: "14px 16px", borderRadius: 10,
              background: selected === msg.id ? "rgba(79,156,249,0.12)" : "rgba(255,255,255,0.03)",
              border: `1px solid ${selected === msg.id ? "rgba(79,156,249,0.3)" : "rgba(255,255,255,0.07)"}`,
              cursor: "pointer", transition: "all 0.2s"
            }}>
              <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                <Avatar initials={msg.avatar} color={msg.color} size={34} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: "#e8edf5" }}>{msg.from}</div>
                    <div style={{ fontSize: 10, color: "#5a7090" }}>{msg.time}</div>
                  </div>
                  <div style={{ fontSize: 12, color: "#8fa3bf", marginTop: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{msg.subject}</div>
                  <div style={{ display: "flex", gap: 4, marginTop: 5 }}>
                    {msg.unread && <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#4f9cf9", display: "inline-block", marginTop: 1 }} />}
                    <Tag color={priorityColor(msg.priority)}>{msg.priority}</Tag>
                    {msg.replies > 0 && <Tag color="gray">{msg.replies} replies</Tag>}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Message detail */}
        {selectedMsg ? (
          <Card>
            <div style={{ display: "flex", gap: 12, alignItems: "flex-start", marginBottom: 16, paddingBottom: 16, borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
              <Avatar initials={selectedMsg.avatar} color={selectedMsg.color} size={44} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 18, fontWeight: 700, color: "#e8edf5", fontFamily: "'Fraunces', serif" }}>{selectedMsg.subject}</div>
                <div style={{ fontSize: 13, color: "#8fa3bf", marginTop: 3 }}>{selectedMsg.from} · {selectedMsg.fromRole}</div>
                <div style={{ fontSize: 12, color: "#5a7090", marginTop: 2 }}>Re: {selectedMsg.student} · {selectedMsg.time}</div>
              </div>
              <Tag color={priorityColor(selectedMsg.priority)}>{selectedMsg.priority}</Tag>
            </div>
            <div style={{ fontSize: 14, color: "#8fa3bf", lineHeight: 1.75, marginBottom: 20 }}>{selectedMsg.body}</div>
            {selectedMsg.student && (
              <div style={{ padding: "10px 14px", background: "rgba(79,156,249,0.08)", border: "1px solid rgba(79,156,249,0.15)", borderRadius: 8, marginBottom: 16 }}>
                <span style={{ fontSize: 12, color: "#4f9cf9" }}>📌 Regarding student: <strong>{selectedMsg.student}</strong></span>
              </div>
            )}
            <div>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#5a7090", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.06em" }}>Reply</div>
              <FormTextarea label="" value={replyText} onChange={setReplyText} placeholder="Type your reply..." rows={3} />
              <div style={{ display: "flex", gap: 8 }}>
                <Btn onClick={handleReply} disabled={!replyText.trim()}><Send size={13} /> Send Reply</Btn>
                <Btn variant="ghost"><FileDown size={13} /> Attach</Btn>
              </div>
            </div>
          </Card>
        ) : (
          <Card style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: 300 }}>
            <div style={{ textAlign: "center", color: "#5a7090" }}>
              <MessageSquare size={40} style={{ marginBottom: 10, opacity: 0.5 }} />
              <div>Select a message to read</div>
            </div>
          </Card>
        )}
      </div>

      {/* Compose Modal */}
      <Modal open={showCompose} onClose={() => setShowCompose(false)} title="New Message">
        <FormSelect label="To" value={form.to} onChange={v => setForm({ ...form, to: v })} options={[...THERAPISTS.map(t => t.name), "All Staff"]} />
        <FormInput label="Regarding Student (optional)" value={form.student} onChange={v => setForm({ ...form, student: v })} placeholder="Student name" />
        <FormInput label="Subject" value={form.subject} onChange={v => setForm({ ...form, subject: v })} placeholder="Message subject" required />
        <FormTextarea label="Message" value={form.body} onChange={v => setForm({ ...form, body: v })} placeholder="Type your message..." />
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#8fa3bf", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.06em" }}>Priority</div>
          <div style={{ display: "flex", gap: 8 }}>
            {["Normal", "Urgent", "For Review"].map(p => (
              <button key={p} onClick={() => setForm({ ...form, priority: p })} style={{
                padding: "6px 14px", borderRadius: 6, border: "1px solid",
                borderColor: form.priority === p ? "#4f9cf9" : "rgba(255,255,255,0.1)",
                background: form.priority === p ? "rgba(79,156,249,0.15)" : "transparent",
                color: form.priority === p ? "#4f9cf9" : "#8fa3bf",
                fontSize: 12, fontWeight: 600, cursor: "pointer", fontFamily: "'DM Sans', sans-serif"
              }}>{p}</button>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
          <Btn variant="ghost" onClick={() => setShowCompose(false)}>Cancel</Btn>
          <Btn onClick={handleSend} disabled={!form.subject || !form.body}><Send size={13} /> Send Message</Btn>
        </div>
      </Modal>
    </div>
  );
};

// ═══════════════════════════════════════════
// RESOURCES VIEW
// ═══════════════════════════════════════════
const ResourcesView = ({ showToast }) => {
  const [resources, setResources] = useState(RESOURCES);
  const [showRequest, setShowRequest] = useState(false);
  const [form, setForm] = useState({ name: "", desc: "", quantity: "", reason: "" });

  const handleRequest = () => {
    showToast("Resource request submitted for approval!", "success");
    setShowRequest(false);
    setForm({ name: "", desc: "", quantity: "", reason: "" });
  };

  const handleCheckout = (id) => {
    setResources(res => res.map(r => r.id === id && r.inUse < r.total ? { ...r, inUse: r.inUse + 1 } : r));
    showToast("Resource checked out successfully!", "success");
  };

  const handleReturn = (id) => {
    setResources(res => res.map(r => r.id === id && r.inUse > 0 ? { ...r, inUse: r.inUse - 1 } : r));
    showToast("Resource returned!", "info");
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div style={{ fontFamily: "'Fraunces', serif", fontSize: 22, fontWeight: 700, color: "#e8edf5" }}>
          Assistive <span style={{ color: "#4f9cf9" }}>Resources</span>
        </div>
        <Btn onClick={() => setShowRequest(true)}><Plus size={15} /> Request Resource</Btn>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16 }}>
        {resources.map(r => {
          const pct = Math.round((r.inUse / r.total) * 100);
          const available = r.total - r.inUse;
          return (
            <Card key={r.id} style={{ borderColor: `${r.color}30` }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
                <div style={{ fontSize: 32 }}>{r.icon}</div>
                <Tag color={pct > 80 ? "red" : pct > 60 ? "amber" : "green"}>{pct}% Used</Tag>
              </div>
              <div style={{ fontSize: 15, fontWeight: 700, color: "#e8edf5", marginBottom: 4 }}>{r.name}</div>
              <div style={{ fontSize: 12, color: "#5a7090", marginBottom: 14 }}>{r.desc}</div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 6 }}>
                <span style={{ color: "#8fa3bf" }}>Available: <strong style={{ color: available > 0 ? "#3ecf8e" : "#f87171" }}>{available}</strong></span>
                <span style={{ color: "#8fa3bf" }}>In Use: <strong style={{ color: "#f59e0b" }}>{r.inUse}</strong></span>
              </div>
              <ProgressBar value={pct} color={r.color} height={6} />
              <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
                <Btn variant="success" size="sm" onClick={() => handleCheckout(r.id)} disabled={available === 0} style={{ flex: 1, justifyContent: "center" }}>
                  <Download size={12} /> Check Out
                </Btn>
                <Btn variant="ghost" size="sm" onClick={() => handleReturn(r.id)} disabled={r.inUse === 0} style={{ flex: 1, justifyContent: "center" }}>
                  <RefreshCw size={12} /> Return
                </Btn>
              </div>
            </Card>
          );
        })}
      </div>

      <Modal open={showRequest} onClose={() => setShowRequest(false)} title="Request New Resource">
        <FormInput label="Resource Name" value={form.name} onChange={v => setForm({ ...form, name: v })} placeholder="e.g. Additional Braille Displays" required />
        <FormInput label="Description" value={form.desc} onChange={v => setForm({ ...form, desc: v })} placeholder="Brief description of the resource" />
        <FormInput label="Quantity Needed" type="number" value={form.quantity} onChange={v => setForm({ ...form, quantity: v })} placeholder="e.g. 5" required />
        <FormTextarea label="Justification" value={form.reason} onChange={v => setForm({ ...form, reason: v })} placeholder="Explain why this resource is needed and which students it will support..." />
        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
          <Btn variant="ghost" onClick={() => setShowRequest(false)}>Cancel</Btn>
          <Btn onClick={handleRequest} disabled={!form.name || !form.quantity}><Send size={13} /> Submit Request</Btn>
        </div>
      </Modal>
    </div>
  );
};

// ═══════════════════════════════════════════
// COMPLIANCE VIEW
// ═══════════════════════════════════════════
const ComplianceView = ({ students, showToast }) => {
  const [items, setItems] = useState(COMPLIANCE_ITEMS);
  const overallScore = Math.round(items.filter(i => i.status === "ok").length / items.length * 100);

  const resolveItem = (id) => {
    setItems(prev => prev.map(i => i.id === id ? { ...i, status: "ok", pct: 100 } : i));
    showToast("Compliance item marked as resolved!", "success");
  };

  const statusIcon = s => ({ ok: <CheckCircle size={16} color="#3ecf8e" />, warn: <AlertCircle size={16} color="#f59e0b" />, fail: <XCircle size={16} color="#f87171" /> })[s];
  const statusColor = s => ({ ok: "green", warn: "amber", fail: "red" })[s];

  const auditEvents = [
    { title: "State Education Board Review", date: "Feb 10, 2026", result: "Passed", notes: "Zero violations. Recommended as model institution.", color: "#3ecf8e" },
    { title: "PWDRA Documentation Check", date: "Jan 25, 2026", result: "Minor Flags", notes: "7 therapy log signatures missing. Deadline: Feb 28.", color: "#f59e0b" },
    { title: "Internal Compliance Review", date: "Jan 5, 2026", result: "Passed", notes: "Q4 2025 records verified. IEPs all up to date.", color: "#4f9cf9" },
  ];

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div style={{ fontFamily: "'Fraunces', serif", fontSize: 22, fontWeight: 700, color: "#e8edf5" }}>
          Compliance & <span style={{ color: "#3ecf8e" }}>Legal Records</span>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <Btn variant="ghost" size="sm" onClick={() => showToast("Audit report printed!", "info")}><Printer size={13} /> Print Audit</Btn>
          <Btn onClick={() => showToast("Compliance report generated!", "success")}><FileDown size={13} /> Generate Report</Btn>
        </div>
      </div>

      {/* Score Banner */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 20 }}>
        <Card style={{ borderTop: "3px solid #3ecf8e" }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#5a7090", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 6 }}>Overall Compliance</div>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 36, fontWeight: 700, color: "#3ecf8e" }}>{overallScore}%</div>
          <ProgressBar value={overallScore} color="#3ecf8e" height={4} />
        </Card>
        <Card style={{ borderTop: "3px solid #4f9cf9" }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#5a7090", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 6 }}>IEPs Active</div>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 36, fontWeight: 700, color: "#4f9cf9" }}>{students.length}</div>
          <div style={{ fontSize: 12, color: "#3ecf8e" }}>100% coverage</div>
        </Card>
        <Card style={{ borderTop: "3px solid #f59e0b" }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#5a7090", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 6 }}>Pending Items</div>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 36, fontWeight: 700, color: "#f59e0b" }}>{items.filter(i => i.status !== "ok").length}</div>
          <div style={{ fontSize: 12, color: "#8fa3bf" }}>Require attention</div>
        </Card>
        <Card style={{ borderTop: "3px solid #3ecf8e" }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#5a7090", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 6 }}>Violations</div>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 36, fontWeight: 700, color: "#3ecf8e" }}>0</div>
          <div style={{ fontSize: 12, color: "#3ecf8e" }}>Clean record ✓</div>
        </Card>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "3fr 2fr", gap: 16 }}>
        {/* Checklist */}
        <Card>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 700, color: "#e8edf5", marginBottom: 16 }}>Compliance Checklist</div>
          {items.map(item => (
            <div key={item.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
              <div style={{ flexShrink: 0 }}>{statusIcon(item.status)}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#e8edf5" }}>{item.title}</div>
                <div style={{ fontSize: 11, color: "#5a7090", marginTop: 2 }}>{item.desc}</div>
              </div>
              <div style={{ display: "flex", gap: 8, alignItems: "center", flexShrink: 0 }}>
                <Tag color={statusColor(item.status)}>{item.status === "ok" ? `${item.pct}%` : item.status === "warn" ? "Pending" : "Overdue"}</Tag>
                {item.status !== "ok" && (
                  <Btn variant="ghost" size="sm" onClick={() => resolveItem(item.id)}><Check size={11} /> Resolve</Btn>
                )}
              </div>
            </div>
          ))}
        </Card>

        {/* Audit log */}
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <Card>
            <div style={{ fontWeight: 700, color: "#e8edf5", fontSize: 14, marginBottom: 14 }}>Audit History</div>
            {auditEvents.map((e, i) => (
              <div key={i} style={{ display: "flex", gap: 12, padding: "12px 0", borderBottom: i < auditEvents.length - 1 ? "1px solid rgba(255,255,255,0.06)" : "none" }}>
                <div style={{ width: 3, borderRadius: 99, background: e.color, flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: "#e8edf5" }}>{e.title}</div>
                  <div style={{ fontSize: 11, color: "#5a7090", marginTop: 2 }}>{e.date} · <span style={{ color: e.color }}>{e.result}</span></div>
                  <div style={{ fontSize: 12, color: "#8fa3bf", marginTop: 4, lineHeight: 1.5 }}>{e.notes}</div>
                </div>
              </div>
            ))}
          </Card>
          <Card style={{ background: "linear-gradient(135deg,rgba(79,156,249,0.06),rgba(62,207,142,0.04))", border: "1px solid rgba(79,156,249,0.15)" }}>
            <div style={{ fontWeight: 700, color: "#e8edf5", fontSize: 14, marginBottom: 12 }}>Generate Report</div>
            <FormSelect label="" value="Full Compliance Report" onChange={() => {}} options={["Full Compliance Report", "IEP Status Report", "Therapy Audit", "Resource Utilization", "Accommodation Records"]} />
            <Btn style={{ width: "100%", justifyContent: "center", marginTop: 4 }} onClick={() => showToast("PDF report generated and downloaded!", "success")}><FileDown size={14} /> Generate PDF</Btn>
          </Card>
        </div>
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════
// REPORTS VIEW
// ═══════════════════════════════════════════
const ReportsView = ({ students, showToast }) => {
  const [generating, setGenerating] = useState(null);

  const reports = [
    { id: "progress", icon: "📊", title: "Student Progress Report", desc: "Individual and cohort academic progress, therapy outcomes, and milestone achievements" },
    { id: "compliance", icon: "🛡", title: "Compliance Audit Report", desc: "PWDRA compliance status, IEP records, and accommodation documentation for submission" },
    { id: "therapy", icon: "🧠", title: "Therapy Effectiveness Report", desc: "Session logs, improvement metrics, specialist utilization, and resource consumption" },
    { id: "resources", icon: "📦", title: "Resource Utilization Report", desc: "Assistive device usage, Braille kit allocation, and procurement recommendations" },
    { id: "cohort", icon: "👥", title: "Cohort Analysis Report", desc: "Disability distribution, demographic breakdown, comparative progress across student groups" },
    { id: "ai", icon: "✦", title: "AI Insights Report", desc: "ML-generated recommendations, predictive risk analysis, and ILP optimization suggestions" },
  ];

  const generate = (id) => {
    setGenerating(id);
    setTimeout(() => { setGenerating(null); showToast("Report generated successfully! PDF is ready.", "success"); }, 2000);
  };

  const summaryStats = [
    { label: "Total Students", val: students.length },
    { label: "Avg Progress", val: `${Math.round(students.reduce((a, s) => a + s.academicProgress, 0) / students.length)}%` },
    { label: "Avg Attendance", val: `${Math.round(students.reduce((a, s) => a + s.attendance, 0) / students.length)}%` },
    { label: "ILPs Active", val: students.length },
    { label: "At Risk", val: students.filter(s => s.riskLevel === "Critical" || s.riskLevel === "Moderate").length },
    { label: "Therapy Sessions", val: students.reduce((a, s) => a + s.therapyLogs.length, 0) },
  ];

  return (
    <div>
      <div style={{ fontFamily: "'Fraunces', serif", fontSize: 22, fontWeight: 700, color: "#e8edf5", marginBottom: 20 }}>
        Reports & <span style={{ color: "#4f9cf9" }}>Export</span>
      </div>

      {/* Summary */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(6,1fr)", gap: 12, marginBottom: 24 }}>
        {summaryStats.map(s => (
          <Card key={s.label} style={{ textAlign: "center", padding: 14 }}>
            <div style={{ fontFamily: "'Fraunces', serif", fontSize: 24, fontWeight: 700, color: "#4f9cf9" }}>{s.val}</div>
            <div style={{ fontSize: 11, color: "#5a7090", marginTop: 2 }}>{s.label}</div>
          </Card>
        ))}
      </div>

      {/* Report cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16 }}>
        {reports.map(r => (
          <Card key={r.id} style={{ display: "flex", flexDirection: "column" }}>
            <div style={{ fontSize: 36, marginBottom: 12 }}>{r.icon}</div>
            <div style={{ fontSize: 15, fontWeight: 700, color: "#e8edf5", marginBottom: 6, flex: 1 }}>{r.title}</div>
            <div style={{ fontSize: 12, color: "#5a7090", marginBottom: 16, lineHeight: 1.6 }}>{r.desc}</div>
            <div style={{ display: "flex", gap: 8 }}>
              <Btn onClick={() => generate(r.id)} disabled={generating === r.id} style={{ flex: 1, justifyContent: "center" }}>
                {generating === r.id ? <><RefreshCw size={13} style={{ animation: "spin 1s linear infinite" }} /> Generating...</> : <><FileDown size={13} /> Generate PDF</>}
              </Btn>
              <Btn variant="ghost" size="sm" onClick={() => showToast("Report preview loading...", "info")}><Eye size={13} /></Btn>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════
// AI INSIGHTS VIEW
// ═══════════════════════════════════════════
const AIView = ({ students, showToast }) => {
  const [selected, setSelected] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState(null);

  const riskData = students.map(s => ({
    name: s.name.split(" ")[0], risk: s.riskLevel === "Critical" ? 4 : s.riskLevel === "Moderate" ? 3 : s.riskLevel === "Low" ? 2 : 1
  }));

  const analyze = () => {
    if (!selected) return;
    setAnalyzing(true);
    setResult(null);
    setTimeout(() => {
      setAnalyzing(false);
      setResult(AI_RECOMMENDATIONS[selected.id] || []);
    }, 2000);
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 22, fontWeight: 700, color: "#e8edf5" }}>
            <Sparkles size={22} style={{ display: "inline", marginRight: 8, color: "#7c6ff7" }} />
            AI <span style={{ color: "#7c6ff7" }}>Insights Engine</span>
          </div>
          <div style={{ fontSize: 13, color: "#5a7090", marginTop: 4 }}>Trained on 50,000+ special education records · Real-time inference · Bias-audited</div>
        </div>
        <Tag color="purple">Model Active · v2.1</Tag>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
        {/* Risk Prediction */}
        <Card>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 700, color: "#e8edf5", marginBottom: 4 }}>Risk <span style={{ color: "#f87171" }}>Prediction</span></div>
          <div style={{ fontSize: 12, color: "#5a7090", marginBottom: 14 }}>AI-computed risk levels based on progress, attendance, and therapy patterns</div>
          {students.map(s => (
            <div key={s.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
              <Avatar initials={s.avatar} color={s.color} size={30} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#e8edf5" }}>{s.name}</div>
                <div style={{ fontSize: 11, color: "#5a7090" }}>{s.disability}</div>
              </div>
              <RiskBadge level={s.riskLevel} />
              <TrendIcon trend={s.trend} />
            </div>
          ))}
        </Card>

        {/* Content personalization */}
        <Card>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 17, fontWeight: 700, color: "#e8edf5", marginBottom: 14 }}>Content <span style={{ color: "#4f9cf9" }}>Personalization</span></div>
          {[
            { mode: "Audio-First", tag: "blue", students: students.filter(s => s.contentMode === "Audio-First"), icon: "🔊", desc: "NVDA-compatible lectures, screen reader quizzes, audio labs" },
            { mode: "Structured Modules", tag: "amber", students: students.filter(s => s.contentMode === "Structured Modules"), icon: "📦", desc: "Visual schedules, 15-min task blocks, routine transitions" },
            { mode: "Sign + Subtitles", tag: "purple", students: students.filter(s => s.contentMode === "Sign + Subtitles"), icon: "🤟", desc: "ISL-annotated videos, real-time captions, BSL dictionary" },
            { mode: "Simplified Visual", tag: "pink", students: students.filter(s => s.contentMode === "Simplified Visual"), icon: "📖", desc: "Dyslexia font, phonics games, minimal word density" },
          ].map(m => (
            <div key={m.mode} style={{ padding: "10px 12px", background: "rgba(255,255,255,0.03)", borderRadius: 8, border: "1px solid rgba(255,255,255,0.07)", marginBottom: 8, display: "flex", gap: 10 }}>
              <span style={{ fontSize: 20, flexShrink: 0 }}>{m.icon}</span>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
                  <span style={{ fontSize: 12, fontWeight: 700, color: "#e8edf5" }}>{m.mode}</span>
                  <Tag color={m.tag}>{m.students.length} students</Tag>
                </div>
                <div style={{ fontSize: 11, color: "#5a7090" }}>{m.desc}</div>
              </div>
            </div>
          ))}
        </Card>
      </div>

      {/* Interactive AI Generator */}
      <Card style={{ border: "1px solid rgba(124,111,247,0.3)", background: "linear-gradient(135deg,rgba(124,111,247,0.06),rgba(79,156,249,0.03))" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
          <Sparkles size={22} style={{ color: "#7c6ff7" }} />
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 18, fontWeight: 700, color: "#e8edf5" }}>AI Learning Plan Generator</div>
          <div style={{ fontSize: 12, color: "#5a7090" }}>Select a student to generate a personalized ILP analysis</div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 16 }}>
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#8fa3bf", marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.06em" }}>Select Student</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {students.map(s => (
                <div key={s.id} onClick={() => { setSelected(s); setResult(null); }} style={{
                  display: "flex", alignItems: "center", gap: 8, padding: "10px 12px", borderRadius: 8,
                  background: selected?.id === s.id ? "rgba(124,111,247,0.15)" : "rgba(255,255,255,0.03)",
                  border: `1px solid ${selected?.id === s.id ? "rgba(124,111,247,0.35)" : "rgba(255,255,255,0.07)"}`,
                  cursor: "pointer", transition: "all 0.2s"
                }}>
                  <Avatar initials={s.avatar} color={s.color} size={28} />
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: "#e8edf5" }}>{s.name}</div>
                    <div style={{ fontSize: 10, color: "#5a7090" }}>{s.disability}</div>
                  </div>
                </div>
              ))}
            </div>
            <Btn onClick={analyze} disabled={!selected || analyzing} style={{ width: "100%", marginTop: 12, justifyContent: "center" }}>
              {analyzing ? <><RefreshCw size={14} style={{ animation: "spin 1s linear infinite" }} /> Analyzing...</> : <><Sparkles size={14} /> Generate Analysis</>}
            </Btn>
          </div>

          <div style={{ minHeight: 300 }}>
            {!selected && !analyzing && !result && (
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", color: "#5a7090" }}>
                <Sparkles size={40} style={{ marginBottom: 10, opacity: 0.4 }} />
                <div style={{ fontSize: 14 }}>Select a student and click Generate</div>
              </div>
            )}
            {analyzing && (
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", color: "#7c6ff7" }}>
                <RefreshCw size={32} style={{ animation: "spin 1.5s linear infinite", marginBottom: 12 }} />
                <div style={{ fontSize: 14, fontWeight: 600 }}>Analyzing {selected?.name}'s profile...</div>
                <div style={{ fontSize: 12, color: "#5a7090", marginTop: 4 }}>Processing 6 months of data</div>
              </div>
            )}
            {result && selected && (
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
                  <Avatar initials={selected.avatar} color={selected.color} size={38} />
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 15, color: "#e8edf5" }}>{selected.name}</div>
                    <div style={{ fontSize: 12, color: "#5a7090" }}>{selected.disability} · {selected.contentMode}</div>
                  </div>
                  <Tag color="purple" style={{ marginLeft: "auto" }}>AI Generated</Tag>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {result.map((rec, i) => (
                    <div key={i} style={{ padding: "12px 14px", background: "rgba(255,255,255,0.04)", borderRadius: 10, border: "1px solid rgba(255,255,255,0.08)", display: "flex", gap: 12 }}>
                      <div style={{ width: 24, height: 24, borderRadius: "50%", background: "rgba(124,111,247,0.2)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: 11, fontWeight: 700, color: "#7c6ff7" }}>{i + 1}</div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13, fontWeight: 700, color: "#e8edf5", marginBottom: 4 }}>{rec.title}</div>
                        <div style={{ fontSize: 12, color: "#8fa3bf", lineHeight: 1.5 }}>{rec.detail}</div>
                        <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
                          <Tag color="blue">Confidence: {rec.confidence}%</Tag>
                          <Tag color="purple">{rec.tag}</Tag>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <Btn variant="ghost" size="sm" onClick={() => showToast("AI recommendations applied to ILP!", "success")} style={{ marginTop: 12 }}>
                  <Check size={13} /> Apply to ILP
                </Btn>
              </div>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
};

// ═══════════════════════════════════════════
// ACCESSIBILITY TOOLBAR
// ═══════════════════════════════════════════
const AccessibilityToolbar = () => {
  const [tts, setTts] = useState(false);
  const [hc, setHc] = useState(false);
  const [dys, setDys] = useState(false);
  const [fontSize, setFontSize] = useState(0);
  const [speaking, setSpeaking] = useState(false);

  const toggleTTS = () => {
    const next = !tts;
    setTts(next);
    if (next) {
      setSpeaking(true);
      const utt = new SpeechSynthesisUtterance("Text to speech enabled. InclusaLearn is ready to assist.");
      utt.rate = 0.9;
      utt.onend = () => setSpeaking(false);
      window.speechSynthesis?.speak(utt);
    } else {
      window.speechSynthesis?.cancel();
      setSpeaking(false);
    }
  };

  const toggleHC = () => {
    const next = !hc;
    setHc(next);
    document.documentElement.style.setProperty("--bg", next ? "#000" : "#0a0f1a");
    document.documentElement.style.setProperty("--surface", next ? "#0a0a0a" : "rgba(17,24,39,0.95)");
    document.documentElement.style.setProperty("--text", next ? "#fff" : "#e8edf5");
    document.documentElement.style.setProperty("--border", next ? "rgba(255,255,255,0.3)" : "rgba(255,255,255,0.08)");
  };

  const toggleDys = () => {
    const next = !dys;
    setDys(next);
    document.body.style.fontFamily = next ? "'Comic Sans MS', cursive" : "";
    document.body.style.letterSpacing = next ? "0.05em" : "";
    document.body.style.lineHeight = next ? "1.9" : "";
    document.body.style.wordSpacing = next ? "0.1em" : "";
  };

  const cycleFontSize = () => {
    const sizes = [0, 1, 2];
    const next = (fontSize + 1) % sizes.length;
    setFontSize(next);
    document.documentElement.style.fontSize = ["16px", "18px", "20px"][next];
  };

  const toggleBtns = [
    { label: "TTS", icon: <Volume2 size={12} />, active: tts, action: toggleTTS, title: "Text-to-Speech" },
    { label: "HC", icon: <Eye size={12} />, active: hc, action: toggleHC, title: "High Contrast" },
    { label: "DYS", icon: <Type size={12} />, active: dys, action: toggleDys, title: "Dyslexia Mode" },
    { label: ["A", "A+", "A++"][fontSize], icon: null, active: fontSize > 0, action: cycleFontSize, title: "Font Size" },
  ];

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "5px 10px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 8 }}>
      <Accessibility size={13} style={{ color: "#5a7090" }} />
      <span style={{ fontSize: 10, color: "#5a7090", fontWeight: 600 }}>Access:</span>
      {toggleBtns.map(b => (
        <button key={b.label} title={b.title} onClick={b.action} style={{
          display: "flex", alignItems: "center", gap: 3, padding: "3px 9px", borderRadius: 5,
          border: "1px solid", borderColor: b.active ? "#4f9cf9" : "rgba(255,255,255,0.1)",
          background: b.active ? "rgba(79,156,249,0.2)" : "transparent",
          color: b.active ? "#4f9cf9" : "#8fa3bf",
          fontSize: 11, fontWeight: 600, cursor: "pointer", fontFamily: "'DM Sans', sans-serif",
          transition: "all 0.2s"
        }}>
          {b.icon}{b.label}
        </button>
      ))}
      {speaking && (
        <div style={{ display: "flex", alignItems: "center", gap: 4, color: "#3ecf8e", fontSize: 11, fontWeight: 600 }}>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 2, height: 12 }}>
            {[1, 2, 3, 4].map(i => (
              <div key={i} style={{ width: 2, background: "#3ecf8e", borderRadius: 1, animation: `wave${i} 0.8s ease infinite`, animationDelay: `${i * 0.15}s`, height: 4 }} />
            ))}
          </div>
          Reading...
        </div>
      )}
    </div>
  );
};

// ═══════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════
export default function App() {
  const [view, setView] = useState("dashboard");
  const [students, setStudents] = useState(INITIAL_STUDENTS);
  const [messages, setMessages] = useState(INITIAL_MESSAGES);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [toast, setToast] = useState(null);
  const [notifications, setNotifications] = useState(3);

  const showToast = useCallback((message, type = "success") => {
    setToast({ message, type, id: Date.now() });
  }, []);

  const addStudent = useCallback((s) => {
    setStudents(prev => [...prev, s]);
    showToast(`${s.name} added successfully!`, "success");
  }, [showToast]);

  const updateStudent = useCallback((id, updates) => {
    setStudents(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
    showToast("Student profile updated!", "success");
  }, [showToast]);

  const logTherapySession = useCallback((studentId, session) => {
    setStudents(prev => prev.map(s => s.id === studentId ? { ...s, therapyLogs: [...s.therapyLogs, session] } : s));
  }, []);

  const addMessage = useCallback((msg) => {
    setMessages(prev => [msg, ...prev]);
  }, []);

  const markRead = useCallback((id) => {
    setMessages(prev => prev.map(m => m.id === id ? { ...m, unread: false } : m));
  }, []);

  const navTo = (v) => {
    setSelectedStudent(null);
    setView(v);
  };

  const viewTitles = {
    dashboard: "Dashboard Overview", students: "Student Profiles",
    "learning-plans": "Learning Plans", progress: "Progress Tracking",
    therapy: "Therapy & Support Logs", collaboration: "Team Collaboration",
    resources: "Assistive Resources", compliance: "Compliance & Legal",
    reports: "Reports & Export", ai: "AI Insights Engine"
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,300;0,600;0,700;1,400&family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap');
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html { font-size: 16px; scroll-behavior: smooth; }
        body { background: #0a0f1a; color: #e8edf5; font-family: 'DM Sans', sans-serif; min-height: 100vh; }
        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 99px; }
        @keyframes slideUp { from { opacity: 0; transform: translateY(16px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.6;transform:scale(0.85)} }
        input[type=range] { -webkit-appearance: none; height: 5px; border-radius: 99px; background: rgba(255,255,255,0.1); }
        input[type=range]::-webkit-slider-thumb { -webkit-appearance: none; width: 16px; height: 16px; border-radius: 50%; background: #4f9cf9; cursor: pointer; }
        select option { background: #1a2235; color: #e8edf5; }
        *:focus-visible { outline: 2px solid #4f9cf9; outline-offset: 2px; }
      `}</style>

      <Sidebar active={view} onNav={navTo} students={students} messages={messages} />

      <div style={{ marginLeft: 260, minHeight: "100vh", display: "flex", flexDirection: "column" }}>
        {/* Topbar */}
        <div style={{
          background: "rgba(17,24,39,0.95)", backdropFilter: "blur(10px)",
          borderBottom: "1px solid rgba(255,255,255,0.06)",
          padding: "14px 28px", display: "flex", alignItems: "center", gap: 16,
          position: "sticky", top: 0, zIndex: 50
        }}>
          <div style={{ fontFamily: "'Fraunces', serif", fontSize: 20, fontWeight: 700, color: "#e8edf5", flex: 1 }}>
            {selectedStudent ? selectedStudent.name : viewTitles[view]}
          </div>
          <AccessibilityToolbar />
          <div style={{ position: "relative", cursor: "pointer" }} onClick={() => setNotifications(0)}>
            <Bell size={20} style={{ color: "#8fa3bf" }} />
            {notifications > 0 && <div style={{ position: "absolute", top: -4, right: -4, width: 14, height: 14, borderRadius: "50%", background: "#f87171", color: "#fff", fontSize: 9, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>{notifications}</div>}
          </div>
          <Btn onClick={() => { setSelectedStudent(null); setView("students"); document.querySelector(".add-student-btn")?.click(); }}>
            <UserPlus size={15} /> Add Student
          </Btn>
        </div>

        {/* Main content */}
        <div style={{ padding: "24px 28px", flex: 1, animation: "slideUp 0.3s ease" }}>
          {selectedStudent ? (
            <StudentDetail
              student={students.find(s => s.id === selectedStudent.id) || selectedStudent}
              onBack={() => setSelectedStudent(null)}
              onUpdate={updateStudent}
            />
          ) : view === "dashboard" ? (
            <DashboardView students={students} messages={messages} onNav={navTo} />
          ) : view === "students" ? (
            <StudentsView students={students} onAddStudent={addStudent} onSelectStudent={(s) => { setSelectedStudent(s); }} />
          ) : view === "learning-plans" ? (
            <LearningPlansView students={students} onUpdate={updateStudent} showToast={showToast} />
          ) : view === "progress" ? (
            <ProgressView students={students} />
          ) : view === "therapy" ? (
            <TherapyView students={students} onLogSession={logTherapySession} showToast={showToast} />
          ) : view === "collaboration" ? (
            <CollaborationView messages={messages} onAddMessage={addMessage} onMarkRead={markRead} showToast={showToast} />
          ) : view === "resources" ? (
            <ResourcesView showToast={showToast} />
          ) : view === "compliance" ? (
            <ComplianceView students={students} showToast={showToast} />
          ) : view === "reports" ? (
            <ReportsView students={students} showToast={showToast} />
          ) : view === "ai" ? (
            <AIView students={students} showToast={showToast} />
          ) : null}
        </div>
      </div>

      {toast && <Toast key={toast.id} message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </>
  );
}
